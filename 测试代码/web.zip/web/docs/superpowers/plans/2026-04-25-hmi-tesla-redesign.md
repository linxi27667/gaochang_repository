# 高昌举升机 HMI 特斯拉风格重构 实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将现有举升机 Web 前端重构为 1024×600 工业触摸屏友好的紧凑界面，采用特斯拉车机+iOS 设计语言。

**Architecture:** 单页 HTML 应用，移除旧侧边栏，改为顶部状态栏 + 三视图（数据面板/设置/操作说明）+ 右上角三点菜单弹出导航 + 底部状态栏。

**Tech Stack:** 纯 HTML + CSS + Vanilla JS，无构建工具。

---

### Task 1: 重写 index.html — 新页面结构

**Files:**
- Rewrite: `index.html`

- [ ] **Step 1: 替换 index.html 为新结构**

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=1024, height=600, initial-scale=1.0">
    <title>高昌举升机 | Gaochang Lift</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/cards.css">
</head>
<body>
    <div class="app-container">
        <!-- Header -->
        <header class="app-header">
            <div class="header-brand">
                <div class="brand-icon">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <rect x="2" y="8" width="3" height="6" rx="1" fill="white"/>
                        <rect x="6.5" y="5" width="3" height="9" rx="1" fill="white"/>
                        <rect x="11" y="2" width="3" height="12" rx="1" fill="white"/>
                    </svg>
                </div>
                <span class="brand-name" data-i18n="brand">高昌举升机</span>
            </div>
            <div class="header-status">
                <div class="status-item" id="headerSystemStatus">
                    <span class="status-dot warning"></span>
                    <span class="status-label" id="headerSystemLabel" data-i18n="status_idle">IDLE</span>
                </div>
                <div class="status-item" id="headerOnline">
                    <span class="status-dot success"></span>
                    <span class="status-label" id="headerOnlineLabel">2/2</span>
                </div>
                <div class="status-item" id="headerSync">
                    <span class="status-dot success"></span>
                    <span class="status-label" id="headerSyncLabel" data-i18n="sync_ok">OK</span>
                </div>
            </div>
            <button class="menu-btn" id="menuBtn" aria-label="Menu">
                <svg width="15" height="15" viewBox="0 0 15 15" fill="currentColor">
                    <circle cx="7.5" cy="3" r="1.5"/>
                    <circle cx="7.5" cy="7.5" r="1.5"/>
                    <circle cx="7.5" cy="12" r="1.5"/>
                </svg>
            </button>
        </header>

        <!-- Main Content Area -->
        <main class="app-main">
            <!-- VIEW: Data Panel (default) -->
            <section id="view-data" class="view active">
                <div class="data-layout">
                    <!-- Left: Data -->
                    <div class="data-left">
                        <div class="section-label" data-i18n="realtime_data">实时数据</div>
                        <!-- Motor combined card -->
                        <div class="motor-combined">
                            <div class="motor-section">
                                <div class="motor-label">
                                    <div class="motor-accent-bar"></div>
                                    <span data-i18n="motor1">MOTOR 1</span>
                                </div>
                                <div class="motor-value-row">
                                    <span class="motor-number" id="motor1-height">120.0</span>
                                    <span class="motor-unit">mm</span>
                                </div>
                                <div class="motor-bar-track">
                                    <div class="motor-bar-fill" id="motor1-bar" style="width:60%"></div>
                                </div>
                                <div class="motor-state-badge" id="motor1-state" data-i18n="status_idle">空闲</div>
                            </div>
                            <div class="motor-divider"></div>
                            <div class="motor-section">
                                <div class="motor-label">
                                    <div class="motor-accent-bar"></div>
                                    <span data-i18n="motor2">MOTOR 2</span>
                                </div>
                                <div class="motor-value-row">
                                    <span class="motor-number" id="motor2-height">118.5</span>
                                    <span class="motor-unit">mm</span>
                                </div>
                                <div class="motor-bar-track">
                                    <div class="motor-bar-fill" id="motor2-bar" style="width:59%"></div>
                                </div>
                                <div class="motor-state-badge" id="motor2-state" data-i18n="status_idle">空闲</div>
                            </div>
                        </div>
                        <!-- Bottom status row -->
                        <div class="status-row">
                            <div class="status-card" id="syncCard">
                                <div class="status-card-icon">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M3 8h10M8 3v10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                    </svg>
                                </div>
                                <div class="status-card-info">
                                    <div class="status-card-label" data-i18n="sync_error">误差</div>
                                    <div class="status-card-value"><span id="sync-value">1.5</span><span class="status-card-unit">mm</span></div>
                                </div>
                                <span class="sync-dot" id="sync-dot"></span>
                            </div>
                            <div class="status-card" id="systemCard">
                                <div class="status-card-icon">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <circle cx="8" cy="8" r="3" stroke="currentColor" stroke-width="1.5"/>
                                        <path d="M8 1v2M8 13v2M1 8h2M13 8h2" stroke="currentColor" stroke-width="1" stroke-linecap="round"/>
                                    </svg>
                                </div>
                                <div class="status-card-info">
                                    <div class="status-card-label" data-i18n="system_status">系统</div>
                                    <div class="status-card-value" id="system-status-value" data-i18n="status_idle">空闲</div>
                                </div>
                            </div>
                            <div class="status-card" id="onlineCard">
                                <div class="status-card-icon">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M3 8l3.5 3.5L13 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </div>
                                <div class="status-card-info">
                                    <div class="status-card-label" data-i18n="online_status">连接</div>
                                    <div class="status-card-value" id="online-status-value">2/2</div>
                                </div>
                            </div>
                            <div class="status-card" id="alarmCard">
                                <div class="status-card-icon">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/>
                                        <path d="M5.5 8l2 2 3-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </div>
                                <div class="status-card-info">
                                    <div class="status-card-label" data-i18n="alarm_info">报警</div>
                                    <div class="status-card-value" id="alarm-status-value" data-i18n="no_alarm">无</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Right: Height Setter -->
                    <div class="data-right">
                        <div class="section-label" data-i18n="height_set">高度设定</div>
                        <div class="height-setter">
                            <div class="current-height">
                                <div class="setter-label" data-i18n="current_height">当前高度</div>
                                <div class="setter-value"><span id="current-height-val">1.20</span><span class="setter-unit"> m</span></div>
                            </div>
                            <div class="setter-divider"></div>
                            <div class="target-height">
                                <div class="setter-label" data-i18n="target_height">目标高度</div>
                                <div class="target-controls">
                                    <button class="setter-btn setter-minus" id="heightMinus">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M5 10h10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        </svg>
                                    </button>
                                    <div class="target-display" id="targetDisplay" tabindex="0">
                                        <span id="target-height-val" class="setter-value">1.20</span>
                                        <span class="setter-unit">m</span>
                                    </div>
                                    <button class="setter-btn setter-plus" id="heightPlus">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M5 10h10M10 5v10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                            <div class="height-slider">
                                <div class="slider-track">
                                    <div class="slider-fill" id="sliderFill" style="width:60%"></div>
                                    <div class="slider-thumb" id="sliderThumb" style="left:60%"></div>
                                </div>
                                <div class="slider-labels">
                                    <span>0.00</span>
                                    <span id="sliderMax">2.00 m</span>
                                </div>
                            </div>
                            <div class="step-selector">
                                <button class="step-btn" data-step="0.01">0.01m</button>
                                <button class="step-btn active" data-step="0.05">0.05m</button>
                                <button class="step-btn" data-step="0.10">0.10m</button>
                            </div>
                            <button class="confirm-btn" id="confirmBtn" data-i18n="confirm_set">确认设定</button>
                        </div>
                    </div>
                </div>
            </section>

            <!-- VIEW: Settings -->
            <section id="view-settings" class="view">
                <div class="settings-container">
                    <div class="settings-section-label" data-i18n="settings_general">通用</div>
                    <div class="settings-group">
                        <div class="setting-row">
                            <span class="setting-label" data-i18n="setting_language">语言</span>
                            <button class="setting-action" id="langDrawerBtn" data-i18n="lang_zh">中文</button>
                        </div>
                        <div class="setting-row">
                            <span class="setting-label" data-i18n="setting_unit">单位</span>
                            <div class="segmented-control">
                                <button class="seg-btn active" data-unit="mm">mm</button>
                                <button class="seg-btn" data-unit="inch">inch</button>
                            </div>
                        </div>
                        <div class="setting-row">
                            <div>
                                <span class="setting-label" data-i18n="setting_demo">演示模式</span>
                                <span class="setting-desc" data-i18n="setting_demo_desc">模拟数据自动更新</span>
                            </div>
                            <div class="toggle-switch" id="demoToggle">
                                <div class="toggle-knob"></div>
                            </div>
                        </div>
                    </div>
                    <div class="settings-section-label" data-i18n="settings_about">关于</div>
                    <div class="settings-group">
                        <div class="setting-row">
                            <span class="setting-label" data-i18n="about_device">设备名称</span>
                            <span class="setting-value" data-i18n="about_device_val">高昌双柱举升机</span>
                        </div>
                        <div class="setting-row">
                            <span class="setting-label" data-i18n="about_version">系统版本</span>
                            <span class="setting-value">gaochangOS v1.0</span>
                        </div>
                        <div class="setting-row">
                            <span class="setting-label" data-i18n="about_max_height">最大高度</span>
                            <span class="setting-value">2.00 m</span>
                        </div>
                        <div class="setting-row">
                            <span class="setting-label" data-i18n="about_comms">通信方式</span>
                            <span class="setting-value">USART</span>
                        </div>
                    </div>
                </div>
            </section>

            <!-- VIEW: Manual -->
            <section id="view-manual" class="view">
                <div class="manual-container">
                    <div class="manual-title" data-i18n="manual_title">高昌丝杆举升机 · 操作指南</div>
                    <div class="manual-steps">
                        <div class="manual-step">
                            <div class="step-num">1</div>
                            <div class="step-content">
                                <div class="step-title" data-i18n="step1_title">查看数据</div>
                                <div class="step-desc" data-i18n="step1_desc">主界面实时显示两立柱高度、同步误差、系统连接状态。</div>
                            </div>
                        </div>
                        <div class="manual-step">
                            <div class="step-num">2</div>
                            <div class="step-content">
                                <div class="step-title" data-i18n="step2_title">设定高度</div>
                                <div class="step-desc" data-i18n="step2_desc">点击 + / − 调节目标高度，步进可调。确认后双柱同步运行至目标高度。</div>
                            </div>
                        </div>
                        <div class="manual-step">
                            <div class="step-num">3</div>
                            <div class="step-content">
                                <div class="step-title" data-i18n="step3_title">报警处理</div>
                                <div class="step-desc" data-i18n="step3_desc">同步误差 >5mm 黄色警告，>10mm 红色报警。堵转报警请立即停机检查。</div>
                            </div>
                        </div>
                        <div class="manual-step">
                            <div class="step-num">4</div>
                            <div class="step-content">
                                <div class="step-title" data-i18n="step4_title">安全须知</div>
                                <div class="step-desc" data-i18n="step4_desc">举升中确保人员安全，严禁超载。定期检查螺母磨损。</div>
                            </div>
                        </div>
                    </div>
                    <div class="manual-footer">
                        <span>gaochangOS v1.0</span>
                        <span>1024 × 600</span>
                    </div>
                </div>
            </section>
        </main>

        <!-- Footer -->
        <footer class="app-footer">
            <span>gaochangOS v1.0</span>
            <span id="uptime">运行 00:00:00</span>
        </footer>

        <!-- Menu Overlay -->
        <div class="menu-overlay" id="menuOverlay">
            <div class="menu-panel" id="menuPanel">
                <div class="menu-title" data-i18n="menu_title">菜单</div>
                <div class="menu-items">
                    <button class="menu-item" data-view="view-data">
                        <div class="menu-item-icon">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                                <rect x="1.5" y="10" width="3" height="6" rx="1" fill="white"/>
                                <rect x="7.5" y="6" width="3" height="10" rx="1" fill="white"/>
                                <rect x="13.5" y="2" width="3" height="14" rx="1" fill="white"/>
                            </svg>
                        </div>
                        <div class="menu-item-text">
                            <div class="menu-item-name" data-i18n="menu_data">数据面板</div>
                            <div class="menu-item-desc" data-i18n="menu_data_desc">实时高度 · 误差 · 状态</div>
                        </div>
                    </button>
                    <button class="menu-item" data-view="view-settings">
                        <div class="menu-item-icon">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                                <path d="M7.5 2h3l.5 2.1a5.2 5.2 0 0 1 2.2 1.3l2-.7 1.5 2.6-1.2 1.8c.1.4.2.9.2 1.4s-.1 1-.2 1.4l1.2 1.8-1.5 2.6-2-.7a5.2 5.2 0 0 1-2.2 1.3L10.5 16h-3l-.5-2.1a5.2 5.2 0 0 1-2.2-1.3l-2 .7-1.5-2.6 1.2-1.8a6.4 6.4 0 0 1-.2-1.4c0-.5.1-1 .2-1.4L1.3 4.3l1.5-2.6 2 .7A5.2 5.2 0 0 1 7 1.1L7.5 2z" stroke="white" stroke-width="1.3"/>
                                <circle cx="9" cy="9" r="2.5" stroke="white" stroke-width="1.3"/>
                            </svg>
                        </div>
                        <div class="menu-item-text">
                            <div class="menu-item-name" data-i18n="menu_settings">设置</div>
                            <div class="menu-item-desc" data-i18n="menu_settings_desc">语言 · 单位 · 关于本机</div>
                        </div>
                    </button>
                    <button class="menu-item" data-view="view-manual">
                        <div class="menu-item-icon">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                                <rect x="3" y="1.5" width="12" height="15" rx="1.5" stroke="white" stroke-width="1.3"/>
                                <path d="M6.5 6h5M6.5 9h5M6.5 12h3" stroke="white" stroke-width="1.2" stroke-linecap="round"/>
                            </svg>
                        </div>
                        <div class="menu-item-text">
                            <div class="menu-item-name" data-i18n="menu_manual">操作说明</div>
                            <div class="menu-item-desc" data-i18n="menu_manual_desc">使用指南 · 安全须知</div>
                        </div>
                    </button>
                </div>
            </div>
        </div>

        <!-- Language Drawer -->
        <div class="lang-drawer-overlay" id="langDrawerOverlay">
            <div class="lang-drawer" id="langDrawer">
                <div class="lang-drawer-title" data-i18n="drawer_lang">选择语言</div>
                <div class="lang-options" id="langOptions">
                    <button class="lang-option active" data-lang="zh">
                        <span>中文</span>
                    </button>
                    <button class="lang-option" data-lang="en">
                        <span>English</span>
                    </button>
                    <button class="lang-option" data-lang="ru">
                        <span>Русский</span>
                    </button>
                    <button class="lang-option" data-lang="de">
                        <span>Deutsch</span>
                    </button>
                    <button class="lang-option" data-lang="fr">
                        <span>Français</span>
                    </button>
                    <button class="lang-option" data-lang="ar">
                        <span>العربية</span>
                    </button>
                    <button class="lang-option" data-lang="es">
                        <span>Español</span>
                    </button>
                    <button class="lang-option" data-lang="tr">
                        <span>Türkçe</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Confirm Dialog -->
        <div class="confirm-overlay" id="confirmOverlay">
            <div class="confirm-dialog">
                <div class="confirm-title" data-i18n="confirm_title">确认设定</div>
                <div class="confirm-message" data-i18n="confirm_msg">是否确认将举升机高度设定为</div>
                <div class="confirm-value" id="confirmValue">1.20 m</div>
                <div class="confirm-sub" data-i18n="confirm_sub">双柱将同步运行至目标高度</div>
                <div class="confirm-actions">
                    <button class="confirm-btn-cancel" id="confirmCancel" data-i18n="confirm_cancel">取消</button>
                    <button class="confirm-btn-ok" id="confirmOk" data-i18n="confirm_ok">确认</button>
                </div>
            </div>
        </div>
    </div>
    <script src="js/i18n.js"></script>
    <script src="js/data.js"></script>
    <script src="js/updates.js"></script>
    <script src="js/app.js"></script>
</body>
</html>
```

- [ ] **Step 2: 删除 css/sidebar.css（侧边栏已移除）**

Run: `rm css/sidebar.css`
Expected: File removed

- [ ] **Step 3: 验证 HTML 结构完整性**

Open `index.html` in browser. Expected: Page renders with header, data panel, footer. CSS will be broken until Tasks 2-3 complete, but DOM structure should be correct.

- [ ] **Step 4: Commit**

```bash
git add index.html
git rm css/sidebar.css
git commit -m "feat: rewrite index.html with new Tesla-style HMI layout, remove sidebar"
```

---

### Task 2: 重写 css/styles.css — 全局变量 + 基础布局

**Files:**
- Rewrite: `css/styles.css`

- [ ] **Step 1: 写入新 styles.css**

```css
:root {
    --bg-primary: #f2f2f7;
    --bg-card: #ffffff;
    --bg-card-secondary: #f9f9fb;
    --accent: #e31938;
    --accent-gradient: linear-gradient(135deg, #e31938, #ff6b81);
    --success: #30d158;
    --warning: #ff9f0a;
    --danger: #e31938;
    --text-primary: #111111;
    --text-secondary: #666666;
    --text-muted: #8e8e93;
    --border: #e5e5e5;
    --border-light: #f2f2f7;
    --shadow-sm: 0 0.5px 2px rgba(0, 0, 0, 0.04);
    --shadow-md: 0 4px 12px rgba(0, 0, 0, 0.08);
    --shadow-lg: 0 8px 30px rgba(0, 0, 0, 0.12);
    --radius: 12px;
    --radius-sm: 8px;
    --radius-xs: 6px;
    --header-height: 42px;
    --footer-height: 24px;
    --font-main: 'Microsoft YaHei', 'PingFang SC', sans-serif;
    --transition: 0.25s ease;
}

*, *::before, *::after {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html, body {
    width: 1024px;
    height: 600px;
    overflow: hidden;
    font-family: var(--font-main);
    font-size: 14px;
    color: var(--text-primary);
    background: var(--bg-primary);
    line-height: 1.5;
}

.app-container {
    width: 1024px;
    height: 600px;
    display: flex;
    flex-direction: column;
    position: relative;
}

/* ===== Header ===== */
.app-header {
    height: var(--header-height);
    background: var(--bg-card);
    border-bottom: 0.5px solid rgba(0, 0, 0, 0.1);
    display: flex;
    align-items: center;
    padding: 0 16px;
    flex-shrink: 0;
}

.header-brand {
    display: flex;
    align-items: center;
    gap: 10px;
}

.brand-icon {
    width: 28px;
    height: 28px;
    background: var(--accent);
    border-radius: var(--radius-xs);
    display: flex;
    align-items: center;
    justify-content: center;
}

.brand-name {
    font-size: 13px;
    font-weight: 700;
    color: var(--text-primary);
    letter-spacing: -0.01em;
}

.header-status {
    flex: 1;
    display: flex;
    gap: 16px;
    align-items: center;
    justify-content: flex-end;
}

.status-item {
    display: flex;
    align-items: center;
    gap: 5px;
}

.status-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--text-muted);
}

.status-dot.success { background: var(--success); }
.status-dot.warning { background: var(--warning); }
.status-dot.danger { background: var(--danger); }

.status-label {
    font-size: 11px;
    color: var(--text-muted);
    font-weight: 500;
}

.menu-btn {
    margin-left: 14px;
    width: 30px;
    height: 30px;
    background: rgba(0, 0, 0, 0.04);
    border: none;
    border-radius: var(--radius-xs);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    color: var(--text-primary);
    transition: background var(--transition);
}

.menu-btn:hover {
    background: rgba(0, 0, 0, 0.08);
}

/* ===== Main ===== */
.app-main {
    flex: 1;
    overflow: hidden;
    position: relative;
}

.view {
    position: absolute;
    inset: 0;
    display: none;
    overflow-y: auto;
}

.view.active {
    display: block;
}

/* ===== Footer ===== */
.app-footer {
    height: var(--footer-height);
    background: var(--bg-card);
    border-top: 0.5px solid rgba(0, 0, 0, 0.1);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 14px;
    font-size: 9px;
    color: var(--text-muted);
    flex-shrink: 0;
}

/* ===== Section Labels ===== */
.section-label {
    font-size: 10px;
    font-weight: 700;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.1em;
    padding: 0 4px;
    margin-bottom: 6px;
}

/* ===== Utility ===== */
.accent { color: var(--accent); }
.success { color: var(--success); }
.warning { color: var(--warning); }
.danger { color: var(--danger); }
.text-secondary { color: var(--text-secondary); }
.text-muted { color: var(--text-muted); }

/* ===== Animations ===== */
@keyframes fade-in {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes slide-up {
    from { transform: translateY(100%); }
    to { transform: translateY(0); }
}

@keyframes slide-down {
    from { transform: translateY(0); }
    to { transform: translateY(100%); }
}

@keyframes fade-bg {
    from { opacity: 0; }
    to { opacity: 1; }
}
```

- [ ] **Step 2: Commit**

```bash
git add css/styles.css
git commit -m "feat: rewrite styles.css with Tesla/iOS design tokens and base layout"
```

---

### Task 3: 重写 css/cards.css — 卡片组件 + 面板样式

**Files:**
- Rewrite: `css/cards.css`

- [ ] **Step 1: 写入新 cards.css**

```css
/* ===== Data Panel Layout ===== */
.data-layout {
    display: flex;
    padding: 10px;
    gap: 10px;
    height: calc(600px - var(--header-height) - var(--footer-height));
}

.data-left {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.data-right {
    width: 280px;
    display: flex;
    flex-direction: column;
    gap: 8px;
}

/* ===== Motor Combined Card ===== */
.motor-combined {
    flex: 2;
    background: var(--bg-card);
    border-radius: var(--radius);
    padding: 14px 16px;
    display: flex;
    align-items: center;
    box-shadow: var(--shadow-sm);
}

.motor-section {
    flex: 1;
    padding: 0;
}

.motor-section:last-child {
    padding-left: 16px;
}

.motor-divider {
    width: 0.5px;
    height: 80%;
    background: var(--border);
    margin: 0 16px;
    flex-shrink: 0;
}

.motor-label {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 8px;
}

.motor-accent-bar {
    width: 4px;
    height: 16px;
    background: var(--accent);
    border-radius: 2px;
    flex-shrink: 0;
}

.motor-label span {
    font-size: 11px;
    font-weight: 700;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.motor-value-row {
    display: flex;
    align-items: baseline;
    gap: 3px;
    margin-bottom: 6px;
}

.motor-number {
    font-size: 44px;
    font-weight: 800;
    color: var(--accent);
    line-height: 1;
}

.motor-unit {
    font-size: 13px;
    color: var(--text-muted);
    font-weight: 500;
}

.motor-bar-track {
    height: 4px;
    background: var(--border-light);
    border-radius: 2px;
    overflow: hidden;
    margin-bottom: 6px;
}

.motor-bar-fill {
    height: 100%;
    background: var(--accent);
    border-radius: 2px;
    transition: width 0.5s ease;
}

.motor-state-badge {
    font-size: 10px;
    font-weight: 600;
    color: var(--accent);
    background: rgba(227, 25, 56, 0.06);
    padding: 2px 6px;
    border-radius: 3px;
    display: inline-block;
}

/* ===== Status Row ===== */
.status-row {
    flex: 1;
    display: flex;
    gap: 8px;
}

.status-card {
    flex: 1;
    background: var(--bg-card);
    border-radius: var(--radius-sm);
    padding: 10px 14px;
    display: flex;
    align-items: center;
    gap: 10px;
    box-shadow: var(--shadow-sm);
}

.status-card-icon {
    width: 32px;
    height: 32px;
    background: var(--border-light);
    border-radius: var(--radius-xs);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--text-muted);
    flex-shrink: 0;
}

#syncCard .status-card-icon { background: var(--border-light); }
#systemCard .status-card-icon { background: #fff3e0; color: var(--warning); }
#onlineCard .status-card-icon { background: #e8f5e9; color: var(--success); }
#alarmCard .status-card-icon { background: #e8f5e9; color: var(--success); }
#alarmCard.has-alarm .status-card-icon { background: #fde8e8; color: var(--danger); }
#alarmCard.has-alarm .status-card-value { color: var(--danger); }

.status-card-info {
    flex: 1;
    min-width: 0;
}

.status-card-label {
    font-size: 9px;
    color: var(--text-muted);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.06em;
}

.status-card-value {
    font-size: 12px;
    font-weight: 700;
    color: var(--text-primary);
}

.status-card-value .status-card-unit {
    font-size: 10px;
    color: var(--text-muted);
    font-weight: 500;
    margin-left: 2px;
}

.sync-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--text-muted);
    flex-shrink: 0;
}

.sync-dot.success { background: var(--success); }
.sync-dot.warning { background: var(--warning); }
.sync-dot.danger { background: var(--danger); }

/* ===== Height Setter ===== */
.height-setter {
    flex: 1;
    background: var(--bg-card);
    border-radius: var(--radius);
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    box-shadow: var(--shadow-sm);
}

.current-height {
    text-align: center;
    padding: 8px 0;
}

.setter-label {
    font-size: 9px;
    color: var(--text-muted);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin-bottom: 4px;
}

.setter-value {
    font-size: 28px;
    font-weight: 800;
    color: var(--text-primary);
}

.setter-unit {
    font-size: 14px;
    color: var(--text-muted);
    font-weight: 500;
}

.setter-divider {
    height: 0.5px;
    background: var(--border-light);
}

.target-height {
    text-align: center;
    padding: 4px 0;
}

.target-controls {
    display: flex;
    align-items: center;
    gap: 8px;
    justify-content: center;
}

.setter-btn {
    width: 44px;
    height: 44px;
    background: var(--border-light);
    border: none;
    border-radius: var(--radius-xs);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    color: var(--accent);
    transition: background var(--transition);
}

.setter-btn:hover {
    background: var(--border);
}

.setter-btn:active {
    background: var(--border);
    transform: scale(0.95);
}

.target-display {
    flex: 1;
    text-align: center;
    background: var(--bg-card-secondary);
    border: 1px solid var(--border);
    border-radius: var(--radius-xs);
    padding: 6px 16px;
    cursor: pointer;
    min-width: 100px;
    transition: border-color var(--transition);
}

.target-display:hover {
    border-color: var(--accent);
}

.target-display .setter-value {
    font-size: 32px;
    font-weight: 800;
    color: var(--text-primary);
}

/* ===== Slider ===== */
.height-slider {
    padding: 4px 0;
}

.slider-track {
    width: 100%;
    height: 4px;
    background: var(--border-light);
    border-radius: 2px;
    position: relative;
}

.slider-fill {
    height: 100%;
    background: var(--accent);
    border-radius: 2px;
    transition: width 0.3s ease;
}

.slider-thumb {
    width: 16px;
    height: 16px;
    background: var(--bg-card);
    border: 2px solid var(--accent);
    border-radius: 50%;
    position: absolute;
    top: -6px;
    transform: translateX(-50%);
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
    cursor: pointer;
}

.slider-labels {
    display: flex;
    justify-content: space-between;
    margin-top: 6px;
    font-size: 9px;
    color: var(--text-muted);
}

/* ===== Step Selector ===== */
.step-selector {
    display: flex;
    gap: 6px;
    justify-content: center;
}

.step-btn {
    padding: 4px 10px;
    background: var(--border-light);
    border: none;
    border-radius: var(--radius-xs);
    font-size: 10px;
    font-weight: 600;
    color: var(--text-secondary);
    cursor: pointer;
    transition: all var(--transition);
}

.step-btn.active {
    background: var(--accent);
    color: #fff;
}

.step-btn:hover:not(.active) {
    background: var(--border);
}

/* ===== Confirm Button ===== */
.confirm-btn {
    margin-top: auto;
    height: 42px;
    background: var(--accent);
    border: none;
    border-radius: var(--radius-xs);
    font-size: 14px;
    font-weight: 700;
    color: #fff;
    cursor: pointer;
    letter-spacing: 0.06em;
    transition: opacity var(--transition);
}

.confirm-btn:hover {
    opacity: 0.9;
}

.confirm-btn:active {
    opacity: 0.8;
}

/* ===== Settings View ===== */
.settings-container {
    padding: 12px;
    height: calc(600px - var(--header-height) - var(--footer-height));
    overflow-y: auto;
}

.settings-section-label {
    font-size: 10px;
    font-weight: 700;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-bottom: 6px;
    padding: 0 4px;
}

.settings-group {
    background: var(--bg-card);
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: var(--shadow-sm);
    margin-bottom: 14px;
}

.setting-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 14px;
    border-bottom: 0.5px solid var(--border-light);
}

.setting-row:last-child {
    border-bottom: none;
}

.setting-label {
    font-size: 13px;
    font-weight: 500;
    color: var(--text-primary);
}

.setting-desc {
    font-size: 10px;
    color: var(--text-muted);
    display: block;
}

.setting-action {
    background: none;
    border: none;
    font-size: 13px;
    font-weight: 500;
    color: var(--text-muted);
    cursor: pointer;
    font-family: var(--font-main);
}

.setting-value {
    font-size: 12px;
    color: var(--text-secondary);
}

/* Segmented Control */
.segmented-control {
    display: flex;
    gap: 6px;
}

.seg-btn {
    padding: 5px 14px;
    background: var(--border-light);
    border: none;
    border-radius: var(--radius-xs);
    font-size: 12px;
    font-weight: 600;
    color: var(--text-secondary);
    cursor: pointer;
    transition: all var(--transition);
    font-family: var(--font-main);
}

.seg-btn.active {
    background: var(--accent);
    color: #fff;
}

/* Toggle Switch */
.toggle-switch {
    width: 42px;
    height: 24px;
    background: #ddd;
    border-radius: 12px;
    position: relative;
    cursor: pointer;
    transition: background var(--transition);
    flex-shrink: 0;
}

.toggle-switch.on {
    background: var(--accent);
}

.toggle-knob {
    width: 20px;
    height: 20px;
    background: #fff;
    border-radius: 50%;
    position: absolute;
    top: 2px;
    left: 2px;
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.12);
    transition: left var(--transition);
}

.toggle-switch.on .toggle-knob {
    left: 20px;
}

/* ===== Manual View ===== */
.manual-container {
    padding: 12px;
    height: calc(600px - var(--header-height) - var(--footer-height));
    overflow-y: auto;
}

.manual-container .manual-card {
    background: var(--bg-card);
    border-radius: var(--radius);
    padding: 16px 18px;
    box-shadow: var(--shadow-sm);
}

.manual-title {
    font-size: 14px;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 16px;
}

.manual-steps {
    display: flex;
    flex-direction: column;
    gap: 14px;
}

.manual-step {
    display: flex;
    gap: 12px;
}

.step-num {
    width: 22px;
    height: 22px;
    background: var(--accent);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    flex-shrink: 0;
    margin-top: 1px;
}

.step-title {
    font-size: 13px;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 3px;
}

.step-desc {
    font-size: 12px;
    color: var(--text-secondary);
    line-height: 1.5;
}

.manual-footer {
    padding-top: 12px;
    border-top: 0.5px solid var(--border-light);
    display: flex;
    justify-content: space-between;
    font-size: 10px;
    color: var(--text-muted);
}

/* ===== Menu Overlay ===== */
.menu-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.3);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 100;
    animation: fade-bg 0.2s ease;
}

.menu-overlay.visible {
    display: flex;
}

.menu-panel {
    width: 340px;
    background: var(--bg-card);
    border-radius: var(--radius);
    padding: 24px 20px;
    box-shadow: var(--shadow-lg);
    animation: fade-in 0.2s ease;
}

.menu-title {
    font-size: 17px;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 18px;
}

.menu-items {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.menu-item {
    height: 64px;
    background: var(--bg-card-secondary);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 0 14px;
    cursor: pointer;
    transition: background var(--transition);
    width: 100%;
    text-align: left;
    font-family: var(--font-main);
}

.menu-item:hover {
    background: var(--border-light);
}

.menu-item-icon {
    width: 36px;
    height: 36px;
    background: var(--accent);
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.menu-item-name {
    font-size: 14px;
    font-weight: 600;
    color: var(--text-primary);
}

.menu-item-desc {
    font-size: 11px;
    color: var(--text-muted);
}

/* ===== Language Drawer ===== */
.lang-drawer-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.3);
    display: none;
    align-items: flex-end;
    justify-content: center;
    z-index: 200;
    animation: fade-bg 0.2s ease;
}

.lang-drawer-overlay.visible {
    display: flex;
}

.lang-drawer {
    width: 100%;
    max-width: 1024px;
    background: var(--bg-card);
    border-radius: var(--radius) var(--radius) 0 0;
    padding: 20px;
    box-shadow: var(--shadow-lg);
    animation: slide-up 0.25s ease;
}

.lang-drawer-title {
    font-size: 15px;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 14px;
    text-align: center;
}

.lang-options {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 8px;
}

.lang-option {
    height: 40px;
    background: var(--bg-card-secondary);
    border: 1px solid var(--border);
    border-radius: var(--radius-xs);
    font-size: 13px;
    font-weight: 600;
    color: var(--text-secondary);
    cursor: pointer;
    transition: all var(--transition);
    font-family: var(--font-main);
}

.lang-option.active {
    background: var(--accent);
    color: #fff;
    border-color: var(--accent);
}

.lang-option:hover:not(.active) {
    background: var(--border-light);
}

/* ===== Confirm Dialog ===== */
.confirm-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.4);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 300;
    animation: fade-bg 0.15s ease;
}

.confirm-overlay.visible {
    display: flex;
}

.confirm-dialog {
    width: 400px;
    background: var(--bg-card);
    border-radius: var(--radius);
    padding: 28px 24px;
    box-shadow: var(--shadow-lg);
    animation: fade-in 0.2s ease;
    text-align: center;
}

.confirm-title {
    font-size: 16px;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 12px;
}

.confirm-message {
    font-size: 13px;
    color: var(--text-secondary);
    margin-bottom: 8px;
}

.confirm-value {
    font-size: 36px;
    font-weight: 800;
    color: var(--accent);
    margin-bottom: 8px;
}

.confirm-sub {
    font-size: 11px;
    color: var(--text-muted);
    margin-bottom: 20px;
}

.confirm-actions {
    display: flex;
    gap: 12px;
}

.confirm-btn-cancel {
    flex: 1;
    height: 44px;
    background: var(--border-light);
    border: none;
    border-radius: var(--radius-sm);
    font-size: 15px;
    font-weight: 600;
    color: var(--text-secondary);
    cursor: pointer;
    transition: background var(--transition);
    font-family: var(--font-main);
}

.confirm-btn-cancel:hover {
    background: var(--border);
}

.confirm-btn-ok {
    flex: 1;
    height: 44px;
    background: var(--accent);
    border: none;
    border-radius: var(--radius-sm);
    font-size: 15px;
    font-weight: 600;
    color: #fff;
    cursor: pointer;
    transition: opacity var(--transition);
    font-family: var(--font-main);
}

.confirm-btn-ok:hover {
    opacity: 0.9;
}
```

- [ ] **Step 2: Commit**

```bash
git add css/cards.css
git commit -m "feat: rewrite cards.css with Tesla/iOS component styles"
```

---

### Task 4: 简化 js/data.js — 核心数据模型

**Files:**
- Rewrite: `js/data.js`

- [ ] **Step 1: 写入新 data.js**

```javascript
(function () {
    'use strict';

    const MAX_HEIGHT_M = 2.00;

    const SystemState = {
        IDLE: 0,
        RISING: 1,
        FALLING: 2,
        ALARM: 3,
    };

    const LiveData = {
        motor1: {
            heightMm: 120.0,
            maxHeightMm: 200.0,
            state: SystemState.IDLE,
        },
        motor2: {
            heightMm: 118.5,
            maxHeightMm: 200.0,
            state: SystemState.IDLE,
        },
        systemState: SystemState.IDLE,
        onlineCount: 2,
        hasAlarm: false,
    };

    const StateLabels = {
        [SystemState.IDLE]: 'status_idle',
        [SystemState.RISING]: 'status_rising',
        [SystemState.FALLING]: 'status_falling',
        [SystemState.ALARM]: 'status_alarm',
    };

    window.LiveData = LiveData;
    window.SystemState = SystemState;
    window.StateLabels = StateLabels;
    window.MAX_HEIGHT_M = MAX_HEIGHT_M;
})();
```

- [ ] **Step 2: Commit**

```bash
git add js/data.js
git commit -m "refactor: simplify data.js to core LiveData + SystemState + StateLabels"
```

---

### Task 5: 重写 js/i18n.js — 多语言 + 抽屉逻辑

**Files:**
- Rewrite: `js/i18n.js`

- [ ] **Step 1: 写入新 i18n.js**

```javascript
(function () {
    'use strict';

    const translations = {
        zh: {
            brand: '高昌举升机',
            status_idle: '空闲',
            status_rising: '上升中',
            status_falling: '下降中',
            status_alarm: '报警',
            sync_ok: 'OK',
            sync_warn: '偏大',
            sync_error_label: '超限',
            realtime_data: '实时数据',
            motor1: '电机 1',
            motor2: '电机 2',
            sync_error: '误差',
            system_status: '系统',
            online_status: '连接',
            alarm_info: '报警',
            no_alarm: '无',
            has_alarm: '报警',
            online_count: '在线',
            height_set: '高度设定',
            current_height: '当前高度',
            target_height: '目标高度',
            confirm_set: '确认设定',
            confirm_title: '确认设定',
            confirm_msg: '是否确认将举升机高度设定为',
            confirm_sub: '双柱将同步运行至目标高度',
            confirm_cancel: '取消',
            confirm_ok: '确认',
            settings_general: '通用',
            settings_about: '关于',
            setting_language: '语言',
            setting_unit: '单位',
            setting_demo: '演示模式',
            setting_demo_desc: '模拟数据自动更新',
            about_device: '设备名称',
            about_device_val: '高昌双柱举升机',
            about_version: '系统版本',
            about_max_height: '最大高度',
            about_comms: '通信方式',
            menu_title: '菜单',
            menu_data: '数据面板',
            menu_data_desc: '实时高度 · 误差 · 状态',
            menu_settings: '设置',
            menu_settings_desc: '语言 · 单位 · 关于本机',
            menu_manual: '操作说明',
            menu_manual_desc: '使用指南 · 安全须知',
            drawer_lang: '选择语言',
            lang_zh: '中文',
            lang_en: 'English',
            lang_ru: 'Русский',
            lang_de: 'Deutsch',
            lang_fr: 'Français',
            lang_ar: 'العربية',
            lang_es: 'Español',
            lang_tr: 'Türkçe',
            manual_title: '高昌丝杆举升机 · 操作指南',
            step1_title: '查看数据',
            step1_desc: '主界面实时显示两立柱高度、同步误差、系统连接状态。绿色 = 正常，黄色 = 待机，红色 = 报警。',
            step2_title: '设定高度',
            step2_desc: '点击 + / − 调节目标高度，步进可调。点击数字可手动输入。确认后双柱同步运行至目标高度。',
            step3_title: '报警处理',
            step3_desc: '同步误差 >5mm 黄色警告，>10mm 红色报警。堵转报警请立即停机检查。',
            step4_title: '安全须知',
            step4_desc: '举升中确保人员安全，严禁超载。定期检查螺母磨损。急停按钮位于控制面板底部。',
        },
        en: {
            brand: 'Gaochang Lift',
            status_idle: 'Idle',
            status_rising: 'Rising',
            status_falling: 'Falling',
            status_alarm: 'Alarm',
            sync_ok: 'OK',
            sync_warn: 'High',
            sync_error_label: 'Over',
            realtime_data: 'Live Data',
            motor1: 'Motor 1',
            motor2: 'Motor 2',
            sync_error: 'Sync Err',
            system_status: 'System',
            online_status: 'Online',
            alarm_info: 'Alarm',
            no_alarm: 'OK',
            has_alarm: 'Alarm',
            online_count: 'Online',
            height_set: 'Height Set',
            current_height: 'Current',
            target_height: 'Target',
            confirm_set: 'Confirm',
            confirm_title: 'Confirm Setting',
            confirm_msg: 'Set lift height to',
            confirm_sub: 'Both columns will move to target',
            confirm_cancel: 'Cancel',
            confirm_ok: 'Confirm',
            settings_general: 'General',
            settings_about: 'About',
            setting_language: 'Language',
            setting_unit: 'Unit',
            setting_demo: 'Demo Mode',
            setting_demo_desc: 'Simulate data updates',
            about_device: 'Device',
            about_device_val: 'Gaochang Dual-Column Lift',
            about_version: 'Version',
            about_max_height: 'Max Height',
            about_comms: 'Communication',
            menu_title: 'Menu',
            menu_data: 'Data Panel',
            menu_data_desc: 'Live height · Error · Status',
            menu_settings: 'Settings',
            menu_settings_desc: 'Language · Unit · About',
            menu_manual: 'Manual',
            menu_manual_desc: 'Guide · Safety',
            drawer_lang: 'Language',
            lang_zh: '中文',
            lang_en: 'English',
            lang_ru: 'Русский',
            lang_de: 'Deutsch',
            lang_fr: 'Français',
            lang_ar: 'العربية',
            lang_es: 'Español',
            lang_tr: 'Türkçe',
            manual_title: 'Gaochang Screw Lift · User Guide',
            step1_title: 'View Data',
            step1_desc: 'Main screen shows real-time column heights, sync error, and system status. Green = OK, Yellow = Standby, Red = Alarm.',
            step2_title: 'Set Height',
            step2_desc: 'Use + / − to adjust target height. Tap the number to type directly. Both columns will move to the target height.',
            step3_title: 'Alarms',
            step3_desc: 'Sync error >5mm shows yellow warning, >10mm triggers red alarm. Stop immediately on stall alarm.',
            step4_title: 'Safety',
            step4_desc: 'Ensure personnel safety during lifting. Do not overload. Check nut wear regularly.',
        },
        ru: {
            brand: 'Gaochang Подъём',
            status_idle: 'Ожидание',
            status_rising: 'Подъём',
            status_falling: 'Спуск',
            status_alarm: 'Сигнал',
            sync_ok: 'Норма',
            sync_warn: 'Высокая',
            sync_error_label: 'Превышен',
            realtime_data: 'Данные',
            motor1: 'Мотор 1',
            motor2: 'Мотор 2',
            sync_error: 'Ош.Синхр',
            system_status: 'Система',
            online_status: 'Связь',
            alarm_info: 'Сигнал',
            no_alarm: 'Нет',
            has_alarm: 'Сигнал',
            online_count: 'Онлайн',
            height_set: 'Высота',
            current_height: 'Текущая',
            target_height: 'Целевая',
            confirm_set: 'Подтвердить',
            confirm_title: 'Подтверждение',
            confirm_msg: 'Установить высоту подъёма',
            confirm_sub: 'Обе колонны переместятся на целевую высоту',
            confirm_cancel: 'Отмена',
            confirm_ok: 'Подтвердить',
            settings_general: 'Общие',
            settings_about: 'О системе',
            setting_language: 'Язык',
            setting_unit: 'Единица',
            setting_demo: 'Демо режим',
            setting_demo_desc: 'Симуляция данных',
            about_device: 'Устройство',
            about_device_val: 'Gaochang Двухколонный Подъём',
            about_version: 'Версия',
            about_max_height: 'Макс Высота',
            about_comms: 'Связь',
            menu_title: 'Меню',
            menu_data: 'Панель данных',
            menu_data_desc: 'Высота · Ошибка · Статус',
            menu_settings: 'Настройки',
            menu_settings_desc: 'Язык · Единица · О системе',
            menu_manual: 'Инструкция',
            menu_manual_desc: 'Руководство · Безопасность',
            drawer_lang: 'Язык',
            lang_zh: '中文',
            lang_en: 'English',
            lang_ru: 'Русский',
            lang_de: 'Deutsch',
            lang_fr: 'Français',
            lang_ar: 'العربية',
            lang_es: 'Español',
            lang_tr: 'Türkçe',
            manual_title: 'Gaochang Винтовой Подъём · Руководство',
            step1_title: 'Просмотр данных',
            step1_desc: 'Главный экран показывает высоту колонн, ошибку синхронизации и статус системы.',
            step2_title: 'Установка высоты',
            step2_desc: 'Используйте + / − для регулировки. Нажмите на цифру для ручного ввода.',
            step3_title: 'Сигналы',
            step3_desc: 'Ошибка синхронизации >5мм — жёлтый, >10мм — красный. Остановите при аварии.',
            step4_title: 'Безопасность',
            step4_desc: 'Обеспечьте безопасность. Не перегружайте. Проверяйте износ гаек.',
        },
        de: {
            brand: 'Gaochang Hebebühne',
            status_idle: 'Leerlauf',
            status_rising: 'Heben',
            status_falling: 'Senken',
            status_alarm: 'Alarm',
            sync_ok: 'OK',
            sync_warn: 'Hoch',
            sync_error_label: 'Über',
            realtime_data: 'Live-Daten',
            motor1: 'Motor 1',
            motor2: 'Motor 2',
            sync_error: 'Sync-Fehler',
            system_status: 'System',
            online_status: 'Verbindung',
            alarm_info: 'Alarm',
            no_alarm: 'OK',
            has_alarm: 'Alarm',
            online_count: 'Online',
            height_set: 'Höhe',
            current_height: 'Aktuell',
            target_height: 'Ziel',
            confirm_set: 'Bestätigen',
            confirm_title: 'Bestätigung',
            confirm_msg: 'Hebehöhe einstellen auf',
            confirm_sub: 'Beide Säulen fahren zur Zielhöhe',
            confirm_cancel: 'Abbrechen',
            confirm_ok: 'Bestätigen',
            settings_general: 'Allgemein',
            settings_about: 'Über',
            setting_language: 'Sprache',
            setting_unit: 'Einheit',
            setting_demo: 'Demo-Modus',
            setting_demo_desc: 'Daten simulieren',
            about_device: 'Gerät',
            about_device_val: 'Gaochang Zweisäulen-Hebebühne',
            about_version: 'Version',
            about_max_height: 'Max Höhe',
            about_comms: 'Kommunikation',
            menu_title: 'Menü',
            menu_data: 'Datenpanel',
            menu_data_desc: 'Höhe · Fehler · Status',
            menu_settings: 'Einstellungen',
            menu_settings_desc: 'Sprache · Einheit · Über',
            menu_manual: 'Anleitung',
            menu_manual_desc: 'Handbuch · Sicherheit',
            drawer_lang: 'Sprache',
            lang_zh: '中文',
            lang_en: 'English',
            lang_ru: 'Русский',
            lang_de: 'Deutsch',
            lang_fr: 'Français',
            lang_ar: 'العربية',
            lang_es: 'Español',
            lang_tr: 'Türkçe',
            manual_title: 'Gaochang Spindelhub · Bedienungsanleitung',
            step1_title: 'Daten anzeigen',
            step1_desc: 'Hauptbildschirm zeigt Höhen, Synchronfehler und Systemstatus.',
            step2_title: 'Höhe einstellen',
            step2_desc: 'Verwenden Sie + / − zur Einstellung. Tippen Sie auf die Zahl zur Eingabe.',
            step3_title: 'Alarme',
            step3_desc: 'Synchronfehler >5mm gelbe Warnung, >10mm roter Alarm.',
            step4_title: 'Sicherheit',
            step4_desc: 'Personensicherheit gewährleisten. Nicht überlasten.',
        },
        fr: {
            brand: 'Gaochang Élévateur',
            status_idle: 'Inactif',
            status_rising: 'Montée',
            status_falling: 'Descente',
            status_alarm: 'Alarme',
            sync_ok: 'OK',
            sync_warn: 'Élevé',
            sync_error_label: 'Excès',
            realtime_data: 'Données',
            motor1: 'Moteur 1',
            motor2: 'Moteur 2',
            sync_error: 'Err.Synch',
            system_status: 'Système',
            online_status: 'Connexion',
            alarm_info: 'Alarme',
            no_alarm: 'OK',
            has_alarm: 'Alarme',
            online_count: 'En ligne',
            height_set: 'Hauteur',
            current_height: 'Actuel',
            target_height: 'Cible',
            confirm_set: 'Confirmer',
            confirm_title: 'Confirmation',
            confirm_msg: 'Définir la hauteur à',
            confirm_sub: 'Les deux colonnes se déplacent à la hauteur cible',
            confirm_cancel: 'Annuler',
            confirm_ok: 'Confirmer',
            settings_general: 'Général',
            settings_about: 'À propos',
            setting_language: 'Langue',
            setting_unit: 'Unité',
            setting_demo: 'Mode Démo',
            setting_demo_desc: 'Simuler les données',
            about_device: 'Appareil',
            about_device_val: 'Gaochang Élévateur Deux Colonnes',
            about_version: 'Version',
            about_max_height: 'Hauteur Max',
            about_comms: 'Communication',
            menu_title: 'Menu',
            menu_data: 'Panneau de données',
            menu_data_desc: 'Hauteur · Erreur · Statut',
            menu_settings: 'Paramètres',
            menu_settings_desc: 'Langue · Unité · À propos',
            menu_manual: 'Manuel',
            menu_manual_desc: 'Guide · Sécurité',
            drawer_lang: 'Langue',
            lang_zh: '中文',
            lang_en: 'English',
            lang_ru: 'Русский',
            lang_de: 'Deutsch',
            lang_fr: 'Français',
            lang_ar: 'العربية',
            lang_es: 'Español',
            lang_tr: 'Türkçe',
            manual_title: 'Gaochang Élévateur à Vis · Guide',
            step1_title: 'Voir les données',
            step1_desc: "L'écran principal affiche les hauteurs, l'erreur de synchronisation et le statut.",
            step2_title: 'Définir la hauteur',
            step2_desc: 'Utilisez + / − pour ajuster. Appuyez sur le nombre pour saisir.',
            step3_title: 'Alarmes',
            step3_desc: "Erreur >5mm avertissement jaune, >10mm alarme rouge. Arrêtez en cas d'alarme.",
            step4_title: 'Sécurité',
            step4_desc: 'Assurez la sécurité. Ne surchargez pas.',
        },
        ar: {
            brand: 'جاوتشانغ رافعة',
            status_idle: 'خامل',
            status_rising: 'صعود',
            status_falling: 'هبوط',
            status_alarm: 'إنذار',
            sync_ok: 'حسناً',
            sync_warn: 'عالي',
            sync_error_label: 'تجاوز',
            realtime_data: 'بيانات حية',
            motor1: 'محرك 1',
            motor2: 'محرك 2',
            sync_error: 'خطأ التزامن',
            system_status: 'نظام',
            online_status: 'اتصال',
            alarm_info: 'إنذار',
            no_alarm: 'لا يوجد',
            has_alarm: 'إنذار',
            online_count: 'متصل',
            height_set: 'ارتفاع',
            current_height: 'حالي',
            target_height: 'مستهدف',
            confirm_set: 'تأكيد',
            confirm_title: 'تأكيد',
            confirm_msg: 'تعيين الارتفاع إلى',
            confirm_sub: 'سيتحرك العمودان إلى الهدف',
            confirm_cancel: 'إلغاء',
            confirm_ok: 'تأكيد',
            settings_general: 'عام',
            settings_about: 'حول',
            setting_language: 'اللغة',
            setting_unit: 'وحدة',
            setting_demo: 'وضع تجريبي',
            setting_demo_desc: 'محاكاة البيانات',
            about_device: 'الجهاز',
            about_device_val: 'جاوتشانغ رافعة عمودين',
            about_version: 'الإصدار',
            about_max_height: 'أقصى ارتفاع',
            about_comms: 'اتصالات',
            menu_title: 'قائمة',
            menu_data: 'لوحة البيانات',
            menu_data_desc: 'ارتفاع · خطأ · حالة',
            menu_settings: 'إعدادات',
            menu_settings_desc: 'لغة · وحدة · حول',
            menu_manual: 'دليل',
            menu_manual_desc: 'دليل · سلامة',
            drawer_lang: 'اللغة',
            lang_zh: '中文',
            lang_en: 'English',
            lang_ru: 'Русский',
            lang_de: 'Deutsch',
            lang_fr: 'Français',
            lang_ar: 'العربية',
            lang_es: 'Español',
            lang_tr: 'Türkçe',
            manual_title: 'جاوتشانغ رافعة لولبية · دليل',
            step1_title: 'عرض البيانات',
            step1_desc: 'الشاشة الرئيسية تعرض الارتفاعات وخطأ التزامن وحالة النظام.',
            step2_title: 'تعيين الارتفاع',
            step2_desc: 'استخدم + / − للتعديل. اضغط على الرقم للإدخال اليدوي.',
            step3_title: 'الإنذارات',
            step3_desc: 'خطأ التزامن >5 ملم تحذير أصفر، >10 ملم إنذار أحمر.',
            step4_title: 'السلامة',
            step4_desc: 'تأكد من السلامة. لا تفرط في التحميل.',
        },
        es: {
            brand: 'Gaochang Elevador',
            status_idle: 'Inactivo',
            status_rising: 'Subiendo',
            status_falling: 'Bajando',
            status_alarm: 'Alarma',
            sync_ok: 'OK',
            sync_warn: 'Alto',
            sync_error_label: 'Exceso',
            realtime_data: 'Datos',
            motor1: 'Motor 1',
            motor2: 'Motor 2',
            sync_error: 'Error Sync',
            system_status: 'Sistema',
            online_status: 'Conexión',
            alarm_info: 'Alarma',
            no_alarm: 'OK',
            has_alarm: 'Alarma',
            online_count: 'En línea',
            height_set: 'Altura',
            current_height: 'Actual',
            target_height: 'Objetivo',
            confirm_set: 'Confirmar',
            confirm_title: 'Confirmación',
            confirm_msg: 'Establecer altura a',
            confirm_sub: 'Ambas columnas se moverán al objetivo',
            confirm_cancel: 'Cancelar',
            confirm_ok: 'Confirmar',
            settings_general: 'General',
            settings_about: 'Acerca de',
            setting_language: 'Idioma',
            setting_unit: 'Unidad',
            setting_demo: 'Modo Demo',
            setting_demo_desc: 'Simular datos',
            about_device: 'Dispositivo',
            about_device_val: 'Gaochang Elevador Dos Columnas',
            about_version: 'Versión',
            about_max_height: 'Altura Máx',
            about_comms: 'Comunicación',
            menu_title: 'Menú',
            menu_data: 'Panel de datos',
            menu_data_desc: 'Altura · Error · Estado',
            menu_settings: 'Ajustes',
            menu_settings_desc: 'Idioma · Unidad · Acerca de',
            menu_manual: 'Manual',
            menu_manual_desc: 'Guía · Seguridad',
            drawer_lang: 'Idioma',
            lang_zh: '中文',
            lang_en: 'English',
            lang_ru: 'Русский',
            lang_de: 'Deutsch',
            lang_fr: 'Français',
            lang_ar: 'العربية',
            lang_es: 'Español',
            lang_tr: 'Türkçe',
            manual_title: 'Gaochang Elevador de Husillo · Guía',
            step1_title: 'Ver datos',
            step1_desc: 'La pantalla principal muestra alturas, error de sincronización y estado.',
            step2_title: 'Establecer altura',
            step2_desc: 'Use + / − para ajustar. Toque el número para ingresar.',
            step3_title: 'Alarmas',
            step3_desc: 'Error >5mm advertencia amarilla, >10mm alarma roja.',
            step4_title: 'Seguridad',
            step4_desc: 'Asegure la seguridad. No sobrecargue.',
        },
        tr: {
            brand: 'Gaochang Asansör',
            status_idle: 'Boşta',
            status_rising: 'Yükseliyor',
            status_falling: 'Alçalıyor',
            status_alarm: 'Alarm',
            sync_ok: 'Tamam',
            sync_warn: 'Yüksek',
            sync_error_label: 'Aşım',
            realtime_data: 'Canlı Veri',
            motor1: 'Motor 1',
            motor2: 'Motor 2',
            sync_error: 'Senk Hata',
            system_status: 'Sistem',
            online_status: 'Bağlantı',
            alarm_info: 'Alarm',
            no_alarm: 'Yok',
            has_alarm: 'Alarm',
            online_count: 'Çevrimiçi',
            height_set: 'Yükseklik',
            current_height: 'Mevcut',
            target_height: 'Hedef',
            confirm_set: 'Onayla',
            confirm_title: 'Onay',
            confirm_msg: 'Yüksekliği ayarla',
            confirm_sub: 'İki kolon hedef yüksekliğe hareket edecek',
            confirm_cancel: 'İptal',
            confirm_ok: 'Onayla',
            settings_general: 'Genel',
            settings_about: 'Hakkında',
            setting_language: 'Dil',
            setting_unit: 'Birim',
            setting_demo: 'Demo Modu',
            setting_demo_desc: 'Verileri simüle et',
            about_device: 'Cihaz',
            about_device_val: 'Gaochang İki Kolonlu Asansör',
            about_version: 'Sürüm',
            about_max_height: 'Maks Yükseklik',
            about_comms: 'İletişim',
            menu_title: 'Menü',
            menu_data: 'Veri Paneli',
            menu_data_desc: 'Yükseklik · Hata · Durum',
            menu_settings: 'Ayarlar',
            menu_settings_desc: 'Dil · Birim · Hakkında',
            menu_manual: 'Kılavuz',
            menu_manual_desc: 'Rehber · Güvenlik',
            drawer_lang: 'Dil',
            lang_zh: '中文',
            lang_en: 'English',
            lang_ru: 'Русский',
            lang_de: 'Deutsch',
            lang_fr: 'Français',
            lang_ar: 'العربية',
            lang_es: 'Español',
            lang_tr: 'Türkçe',
            manual_title: 'Gaochang Vidalı Asansör · Kılavuz',
            step1_title: 'Verileri Görüntüle',
            step1_desc: 'Ana ekran yükseklikleri, senkronizasyon hatasını ve durumu gösterir.',
            step2_title: 'Yükseklik Ayarla',
            step2_desc: '+ / − ile ayarlayın. Sayıya dokunarak manuel girin.',
            step3_title: 'Alarmlar',
            step3_desc: 'Senkronizasyon hatası >5mm sarı uyarı, >10mm kırmızı alarm.',
            step4_title: 'Güvenlik',
            step4_desc: 'Güvenliği sağlayın. Aşırı yüklemeyin.',
        },
    };

    let currentLang = 'zh';

    function setLanguage(lang) {
        if (!translations[lang]) return;
        currentLang = lang;
        document.documentElement.lang = lang;

        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.dataset.i18n;
            if (translations[lang][key]) {
                el.textContent = translations[lang][key];
            }
        });

        // Update language button label in settings
        const langBtn = document.getElementById('langDrawerBtn');
        if (langBtn) {
            const langKey = 'lang_' + lang;
            if (translations[lang][langKey]) {
                langBtn.textContent = translations[lang][langKey];
            }
        }

        // Update active state on lang options
        document.querySelectorAll('.lang-option').forEach(opt => {
            opt.classList.toggle('active', opt.dataset.lang === lang);
        });
    }

    function t(key) {
        return translations[currentLang]?.[key] || key;
    }

    window.I18n = { setLanguage, t, getLang: () => currentLang };
})();
```

- [ ] **Step 2: Commit**

```bash
git add js/i18n.js
git commit -m "feat: rewrite i18n.js with 8 languages and drawer-style language picker"
```

---

### Task 6: 重写 js/updates.js — 数据模拟 + UI 更新 + 运行时间

**Files:**
- Rewrite: `js/updates.js`

- [ ] **Step 1: 写入新 updates.js**

```javascript
(function () {
    'use strict';

    let simPhase = 'idle';
    let simTimer = 0;
    let uptimeSeconds = 0;

    function simulateData() {
        simTimer++;

        if (simPhase === 'idle' && simTimer > 30) {
            simPhase = 'rising';
            simTimer = 0;
            LiveData.systemState = SystemState.RISING;
        } else if (simPhase === 'rising' && simTimer > 80) {
            simPhase = 'idle';
            simTimer = 0;
            LiveData.systemState = SystemState.IDLE;
        }

        if (simPhase === 'rising') {
            LiveData.motor1.heightMm = Math.min(LiveData.motor1.heightMm + 0.8, LiveData.motor1.maxHeightMm);
            LiveData.motor2.heightMm = Math.min(LiveData.motor2.heightMm + 0.7 + Math.random() * 0.2, LiveData.motor2.maxHeightMm);
        } else {
            LiveData.motor1.heightMm += (Math.random() - 0.5) * 0.2;
            LiveData.motor2.heightMm += (Math.random() - 0.5) * 0.2;
        }

        LiveData.motor1.heightMm = Math.max(0, LiveData.motor1.heightMm);
        LiveData.motor2.heightMm = Math.max(0, LiveData.motor2.heightMm);
    }

    function updateUI() {
        const { motor1, motor2, systemState, onlineCount, hasAlarm } = LiveData;
        if (typeof I18n === 'undefined') return;

        // Motor heights
        document.getElementById('motor1-height').textContent = motor1.heightMm.toFixed(1);
        document.getElementById('motor2-height').textContent = motor2.heightMm.toFixed(1);

        // Motor bars
        document.getElementById('motor1-bar').style.width = (motor1.heightMm / motor1.maxHeightMm * 100) + '%';
        document.getElementById('motor2-bar').style.width = (motor2.heightMm / motor2.maxHeightMm * 100) + '%';

        // Motor state badges
        const s1El = document.getElementById('motor1-state');
        const s2El = document.getElementById('motor2-state');
        if (s1El) s1El.textContent = I18n.t(StateLabels[motor1.state] || 'status_idle');
        if (s2El) s2El.textContent = I18n.t(StateLabels[motor2.state] || 'status_idle');

        // Sync error
        const syncDiff = Math.abs(motor1.heightMm - motor2.heightMm);
        document.getElementById('sync-value').textContent = syncDiff.toFixed(1);

        // Sync dot color
        const syncDot = document.getElementById('sync-dot');
        if (syncDot) {
            syncDot.className = 'sync-dot';
            if (syncDiff > 10) syncDot.classList.add('danger');
            else if (syncDiff > 5) syncDot.classList.add('warning');
            else syncDot.classList.add('success');
        }

        // Current height (in meters)
        const currentHeightM = motor1.heightMm / 1000;
        document.getElementById('current-height-val').textContent = currentHeightM.toFixed(2);

        // System status
        document.getElementById('system-status-value').textContent = I18n.t(StateLabels[systemState] || 'status_idle');
        document.getElementById('headerSystemLabel').textContent = I18n.t(StateLabels[systemState] || 'status_idle');

        // Header status dot
        const headerDot = document.querySelector('#headerSystemStatus .status-dot');
        if (headerDot) {
            headerDot.className = 'status-dot';
            if (systemState === SystemState.ALARM) headerDot.classList.add('danger');
            else if (systemState === SystemState.IDLE) headerDot.classList.add('warning');
            else headerDot.classList.add('success');
        }

        // Online status
        document.getElementById('online-status-value').textContent = onlineCount + '/2';
        document.getElementById('headerOnlineLabel').textContent = onlineCount + '/2';

        // Alarm status
        document.getElementById('alarm-status-value').textContent = I18n.t(hasAlarm ? 'has_alarm' : 'no_alarm');
        const alarmCard = document.getElementById('alarmCard');
        if (alarmCard) {
            alarmCard.classList.toggle('has-alarm', hasAlarm);
        }

        // Header sync label
        document.getElementById('headerSyncLabel').textContent = I18n.t(syncDiff <= 2 ? 'sync_ok' : syncDiff <= 5 ? 'sync_warn' : 'sync_error_label');
    }

    function updateUptime() {
        uptimeSeconds++;
        const h = String(Math.floor(uptimeSeconds / 3600)).padStart(2, '0');
        const m = String(Math.floor((uptimeSeconds % 3600) / 60)).padStart(2, '0');
        const s = String(uptimeSeconds % 60).padStart(2, '0');
        const el = document.getElementById('uptime');
        if (el) el.textContent = '运行 ' + h + ':' + m + ':' + s;
    }

    let tickCount = 0;
    function tick() {
        simulateData();
        updateUI();
        tickCount++;
        if (tickCount % 10 === 0) {
            updateUptime();
        }
    }

    window.startSimulation = function () {
        setInterval(tick, 100);
        updateUptime();
    };
})();
```

- [ ] **Step 2: Commit**

```bash
git add js/updates.js
git commit -m "feat: rewrite updates.js with simulation, UI updates, and uptime counter"
```

---

### Task 7: 重写 js/app.js — 视图切换 + 菜单 + 语言抽屉 + 高度设定交互

**Files:**
- Rewrite: `js/app.js`

- [ ] **Step 1: 写入新 app.js**

```javascript
(function () {
    'use strict';

    const App = {
        targetHeightM: 1.20,
        stepM: 0.05,
        maxM: 2.00,
        minM: 0.00,
        demoMode: true,

        init() {
            this.bindMenu();
            this.bindViews();
            this.bindHeightControls();
            this.bindSettings();
            this.bindLanguage();
            this.bindConfirm();
            const savedLang = localStorage.getItem('app-lang') || 'zh';
            this.applyLanguage(savedLang);
            this.updateTargetDisplay();
            if (window.startSimulation) {
                window.startSimulation();
            }
        },

        // Menu
        bindMenu() {
            const btn = document.getElementById('menuBtn');
            const overlay = document.getElementById('menuOverlay');
            const items = document.querySelectorAll('.menu-item');

            btn.addEventListener('click', () => {
                overlay.classList.add('visible');
            });

            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) overlay.classList.remove('visible');
            });

            items.forEach(item => {
                item.addEventListener('click', () => {
                    const viewId = item.dataset.view;
                    this.switchView(viewId);
                    overlay.classList.remove('visible');
                });
            });
        },

        // View switching
        bindViews() {
            // No explicit binding needed — handled by switchView
        },

        switchView(viewId) {
            document.querySelectorAll('.view').forEach(v => {
                v.classList.toggle('active', v.id === viewId);
            });
        },

        // Height controls
        bindHeightControls() {
            const minusBtn = document.getElementById('heightMinus');
            const plusBtn = document.getElementById('heightPlus');
            const targetDisplay = document.getElementById('targetDisplay');
            const confirmBtn = document.getElementById('confirmBtn');
            const stepBtns = document.querySelectorAll('.step-btn');
            const sliderThumb = document.getElementById('sliderThumb');

            minusBtn.addEventListener('click', () => {
                this.targetHeightM = Math.max(this.minM, this.targetHeightM - this.stepM);
                this.updateTargetDisplay();
            });

            plusBtn.addEventListener('click', () => {
                this.targetHeightM = Math.min(this.maxM, this.targetHeightM + this.stepM);
                this.updateTargetDisplay();
            });

            // Click target to manually input
            targetDisplay.addEventListener('click', () => {
                const input = prompt(I18n.t('target_height') + ' (m):', this.targetHeightM.toFixed(2));
                if (input !== null) {
                    const val = parseFloat(input);
                    if (!isNaN(val) && val >= this.minM && val <= this.maxM) {
                        this.targetHeightM = val;
                        this.updateTargetDisplay();
                    }
                }
            });

            // Step selector
            stepBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    stepBtns.forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                    this.stepM = parseFloat(btn.dataset.step);
                });
            });

            // Slider drag
            let dragging = false;
            const startDrag = (e) => {
                dragging = true;
                this.handleSliderMove(e);
            };
            const moveDrag = (e) => {
                if (dragging) this.handleSliderMove(e);
            };
            const endDrag = () => { dragging = false; };

            sliderThumb.addEventListener('mousedown', startDrag);
            sliderThumb.addEventListener('touchstart', startDrag);
            document.addEventListener('mousemove', moveDrag);
            document.addEventListener('touchmove', moveDrag);
            document.addEventListener('mouseup', endDrag);
            document.addEventListener('touchend', endDrag);

            // Confirm button
            confirmBtn.addEventListener('click', () => {
                this.showConfirm();
            });
        },

        handleSliderMove(e) {
            const track = document.querySelector('.slider-track');
            if (!track) return;
            const rect = track.getBoundingClientRect();
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            let pct = (clientX - rect.left) / rect.width;
            pct = Math.max(0, Math.min(1, pct));
            this.targetHeightM = this.minM + pct * (this.maxM - this.minM);
            this.targetHeightM = Math.round(this.targetHeightM * 100) / 100;
            this.updateTargetDisplay();
        },

        updateTargetDisplay() {
            document.getElementById('target-height-val').textContent = this.targetHeightM.toFixed(2);
            document.getElementById('confirmValue').textContent = this.targetHeightM.toFixed(2) + ' m';
            const pct = (this.targetHeightM - this.minM) / (this.maxM - this.minM) * 100;
            document.getElementById('sliderFill').style.width = pct + '%';
            document.getElementById('sliderThumb').style.left = pct + '%';
        },

        // Settings
        bindSettings() {
            // Demo toggle
            const toggle = document.getElementById('demoToggle');
            toggle.addEventListener('click', () => {
                this.demoMode = !this.demoMode;
                toggle.classList.toggle('on', this.demoMode);
            });
            // Default on
            toggle.classList.add('on');

            // Unit segmented control
            const segBtns = document.querySelectorAll('.seg-btn');
            segBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    segBtns.forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                });
            });
        },

        // Language drawer
        bindLanguage() {
            const langBtn = document.getElementById('langDrawerBtn');
            const overlay = document.getElementById('langDrawerOverlay');
            const options = document.querySelectorAll('.lang-option');

            langBtn.addEventListener('click', () => {
                overlay.classList.add('visible');
            });

            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) overlay.classList.remove('visible');
            });

            options.forEach(opt => {
                opt.addEventListener('click', () => {
                    this.applyLanguage(opt.dataset.lang);
                    overlay.classList.remove('visible');
                });
            });
        },

        applyLanguage(lang) {
            if (window.I18n) {
                window.I18n.setLanguage(lang);
            }
            localStorage.setItem('app-lang', lang);
        },

        // Confirm dialog
        bindConfirm() {
            const overlay = document.getElementById('confirmOverlay');
            const cancelBtn = document.getElementById('confirmCancel');
            const okBtn = document.getElementById('confirmOk');

            cancelBtn.addEventListener('click', () => {
                overlay.classList.remove('visible');
            });

            okBtn.addEventListener('click', () => {
                // In real implementation, send command to MCU via USART
                overlay.classList.remove('visible');
            });

            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) overlay.classList.remove('visible');
            });
        },

        showConfirm() {
            document.getElementById('confirmValue').textContent = this.targetHeightM.toFixed(2) + ' m';
            document.getElementById('confirmOverlay').classList.add('visible');
        }
    };

    document.addEventListener('DOMContentLoaded', () => App.init());
    window.App = App;
})();
```

- [ ] **Step 2: Commit**

```bash
git add js/app.js
git commit -m "feat: rewrite app.js with menu, language drawer, height controls, and confirm dialog"
```

---

### Task 8: 验证 + 测试

**Files:**
- All files above

- [ ] **Step 1: Open index.html in browser**

Open `E:\MCU\高昌\测试代码\web\index.html` in browser. Expected:
- Header with GC logo, status indicators, menu button
- Data panel: two motor cards + status row + height setter panel
- Footer with version and uptime counter

- [ ] **Step 2: Test menu interaction**

Click ☰ button. Expected: Dark overlay + white menu panel with 3 items. Click an item switches to that view. Click overlay closes menu.

- [ ] **Step 3: Test language drawer**

Go to Settings → click "语言" button. Expected: Bottom drawer slides up with 8 language options. Click one changes all text on page.

- [ ] **Step 4: Test height controls**

Click +/− buttons: target height changes by step value. Drag slider: target updates. Click target number: prompts for manual input. Click "确认设定": shows confirm dialog.

- [ ] **Step 5: Test data simulation**

Wait a few seconds. Expected: Motor numbers animate, bars move, uptime counter increments every second.

- [ ] **Step 6: Final commit**

```bash
git status
git commit -m "feat: complete Tesla-style HMI redesign for 1024x600 touchscreen"
```
