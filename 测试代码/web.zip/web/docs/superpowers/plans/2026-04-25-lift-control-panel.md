# 高昌丝杆举升机控制面板 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 构建一个特斯拉 Model S 风格的深色科技风 Web 控制面板，用于展示双电机丝杆举升机的实时状态、健康度、报警信息等。

**Architecture:** 单页 HTML 应用，纯静态文件无构建工具。左侧 1/8 侧边栏导航切换视图，右侧主区域展示数据卡片。通过 JavaScript 模拟实时数据动态更新。

**Tech Stack:** HTML5 + CSS3 + Vanilla JavaScript + Google Fonts (Orbitron + Noto Sans SC)

---

## File Structure

| File | Responsibility |
|------|---------------|
| `index.html` | 主页面入口，包含所有 HTML 结构 |
| `css/styles.css` | 全局样式、主题变量、布局、动画 |
| `css/sidebar.css` | 侧边栏专属样式 |
| `css/cards.css` | 数据卡片样式 |
| `css/instruments.css` | 仪表盘组件样式 |
| `js/app.js` | 应用入口、路由切换、初始化 |
| `js/data.js` | 模拟数据源、数据模型定义 |
| `js/updates.js` | 实时数据更新逻辑、动画触发 |
| `js/i18n.js` | 多语言字典、翻译函数 |

所有文件从头编写，无已有代码需要修改。

---

### Task 1: 页面骨架 + 侧边栏

**Files:**
- Create: `E:/MCU/高昌/测试代码/web/index.html`
- Create: `E:/MCU/高昌/测试代码/web/css/styles.css`
- Create: `E:/MCU/高昌/测试代码/web/css/sidebar.css`

- [ ] **Step 1: 创建 index.html 基本结构**

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>高昌举升机 | Gaochang Lift</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Noto+Sans+SC:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/cards.css">
    <link rel="stylesheet" href="css/instruments.css">
</head>
<body>
    <div class="app-container">
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-logo">
                <span class="logo-icon">◆</span>
                <span class="logo-text" data-i18n="logo">高昌举升机</span>
            </div>
            <nav class="sidebar-nav">
                <button class="nav-item active" data-view="home">
                    <span class="nav-icon">🏠</span>
                    <span data-i18n="nav_home">主页</span>
                </button>
                <button class="nav-item" data-view="dashboard">
                    <span class="nav-icon">📊</span>
                    <span data-i18n="nav_dashboard">仪表盘</span>
                </button>
                <button class="nav-item" data-view="status">
                    <span class="nav-icon">🔧</span>
                    <span data-i18n="nav_status">设备状态</span>
                </button>
                <button class="nav-item" data-view="alarms">
                    <span class="nav-icon">⚠</span>
                    <span data-i18n="nav_alarms">报警记录</span>
                </button>
                <button class="nav-item" data-view="settings">
                    <span class="nav-icon">⚙</span>
                    <span data-i18n="nav_settings">设置</span>
                </button>
            </nav>
            <div class="sidebar-footer">
                <div class="lang-selector">
                    <span class="lang-icon">🌐</span>
                    <select id="langSelect">
                        <option value="zh">中文</option>
                        <option value="en">English</option>
                        <option value="ru">Русский</option>
                    </select>
                </div>
            </div>
        </aside>
        <main class="main-content" id="mainContent">
            <!-- 视图容器：各视图初始隐藏，仅 home 可见 -->
        </main>
    </div>
    <script src="js/i18n.js"></script>
    <script src="js/data.js"></script>
    <script src="js/updates.js"></script>
    <script src="js/app.js"></script>
</body>
</html>
```

- [ ] **Step 2: 创建 css/styles.css 全局样式**

```css
/* ===== CSS Variables ===== */
:root {
    --bg-primary: #0a0e14;
    --bg-secondary: #111820;
    --bg-card: #161e28;
    --bg-card-hover: #1c2633;
    --bg-sidebar: #080b0f;
    --text-primary: #e8edf2;
    --text-secondary: #8a96a3;
    --text-muted: #4a5568;
    --accent: #00d4ff;
    --accent-glow: rgba(0, 212, 255, 0.15);
    --accent-dim: rgba(0, 212, 255, 0.08);
    --success: #00e676;
    --warning: #ffab00;
    --danger: #ff1744;
    --border: rgba(255, 255, 255, 0.06);
    --radius: 12px;
    --radius-sm: 8px;
    --sidebar-width: calc(100vw / 8);
    --font-display: 'Orbitron', monospace;
    --font-body: 'Noto Sans SC', sans-serif;
    --transition: 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

/* ===== Reset & Base ===== */
*, *::before, *::after {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html, body {
    height: 100%;
    overflow: hidden;
}

body {
    font-family: var(--font-body);
    background: var(--bg-primary);
    color: var(--text-primary);
    font-size: 14px;
    line-height: 1.6;
}

/* ===== App Container ===== */
.app-container {
    display: flex;
    height: 100vh;
    width: 100vw;
}

/* ===== Main Content ===== */
.main-content {
    flex: 1;
    padding: 24px 32px;
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: var(--text-muted) transparent;
}

.main-content::-webkit-scrollbar {
    width: 6px;
}

.main-content::-webkit-scrollbar-track {
    background: transparent;
}

.main-content::-webkit-scrollbar-thumb {
    background: var(--text-muted);
    border-radius: 3px;
}

/* ===== Typography ===== */
h1, h2, h3 {
    font-family: var(--font-display);
    font-weight: 600;
    letter-spacing: 0.05em;
}

/* ===== Animations ===== */
@keyframes pulse-glow {
    0%, 100% { box-shadow: 0 0 8px var(--accent-glow); }
    50% { box-shadow: 0 0 20px var(--accent-glow), 0 0 40px rgba(0, 212, 255, 0.08); }
}

@keyframes fade-in {
    from { opacity: 0; transform: translateY(12px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes shimmer {
    0% { background-position: -200% 0; }
    100% { background-position: 200% 0; }
}

.view-section {
    animation: fade-in 0.4s ease-out;
}

.view-section.hidden {
    display: none;
}

/* ===== Utility ===== */
.accent { color: var(--accent); }
.success { color: var(--success); }
.warning { color: var(--warning); }
.danger { color: var(--danger); }
.text-muted { color: var(--text-secondary); }
.text-mono { font-family: var(--font-display); }
```

- [ ] **Step 3: 创建 css/sidebar.css 侧边栏样式**

```css
/* ===== Sidebar ===== */
.sidebar {
    width: var(--sidebar-width);
    min-width: 140px;
    max-width: 180px;
    background: var(--bg-sidebar);
    border-right: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    position: relative;
}

.sidebar::after {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 1px;
    height: 100%;
    background: linear-gradient(
        to bottom,
        transparent,
        var(--accent) 20%,
        var(--accent) 80%,
        transparent
    );
    opacity: 0.3;
}

/* ===== Logo ===== */
.sidebar-logo {
    padding: 20px 12px;
    display: flex;
    align-items: center;
    gap: 8px;
    border-bottom: 1px solid var(--border);
}

.logo-icon {
    font-size: 18px;
    color: var(--accent);
    text-shadow: 0 0 12px var(--accent-glow);
}

.logo-text {
    font-family: var(--font-display);
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.1em;
    color: var(--text-primary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* ===== Navigation ===== */
.sidebar-nav {
    flex: 1;
    padding: 12px 8px;
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.nav-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 12px;
    background: transparent;
    border: none;
    border-radius: var(--radius-sm);
    color: var(--text-secondary);
    font-family: var(--font-body);
    font-size: 13px;
    font-weight: 400;
    cursor: pointer;
    transition: var(--transition);
    text-align: left;
    white-space: nowrap;
}

.nav-item:hover {
    background: var(--accent-dim);
    color: var(--text-primary);
}

.nav-item.active {
    background: var(--accent-glow);
    color: var(--accent);
    font-weight: 500;
}

.nav-item.active::before {
    content: '';
    position: absolute;
    left: 0;
    width: 3px;
    height: 60%;
    background: var(--accent);
    border-radius: 0 2px 2px 0;
}

.nav-icon {
    font-size: 16px;
    width: 20px;
    text-align: center;
    flex-shrink: 0;
}

/* ===== Footer / Language ===== */
.sidebar-footer {
    padding: 12px;
    border-top: 1px solid var(--border);
}

.lang-selector {
    display: flex;
    align-items: center;
    gap: 8px;
}

.lang-icon {
    font-size: 14px;
}

#langSelect {
    flex: 1;
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    color: var(--text-primary);
    font-family: var(--font-body);
    font-size: 12px;
    padding: 6px 8px;
    cursor: pointer;
    outline: none;
    transition: var(--transition);
}

#langSelect:hover {
    border-color: var(--accent);
}

#langSelect:focus {
    box-shadow: 0 0 0 2px var(--accent-glow);
}

#langSelect option {
    background: var(--bg-card);
    color: var(--text-primary);
}
```

- [ ] **Step 4: 创建 js/app.js 应用入口（基础路由）**

```javascript
(function () {
    'use strict';

    const App = {
        currentView: 'home',

        init() {
            this.bindNavigation();
            this.bindLanguage();
            this.applyLanguage('zh');
        },

        bindNavigation() {
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach(btn => {
                btn.addEventListener('click', () => {
                    const view = btn.dataset.view;
                    this.switchView(view);
                });
            });
        },

        switchView(viewName) {
            // Update nav active state
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.toggle('active', item.dataset.view === viewName);
            });

            // Toggle view visibility (to be extended in later tasks)
            const views = document.querySelectorAll('.view-section');
            views.forEach(v => {
                v.classList.toggle('hidden', v.id !== `view-${viewName}`);
            });

            this.currentView = viewName;
        },

        bindLanguage() {
            const select = document.getElementById('langSelect');
            select.addEventListener('change', (e) => {
                this.applyLanguage(e.target.value);
            });
        },

        applyLanguage(lang) {
            // Placeholder — i18n.js will implement this
            console.log('Language switched to:', lang);
        }
    };

    document.addEventListener('DOMContentLoaded', () => App.init());
    window.App = App;
})();
```

- [ ] **Step 5: 验证页面可运行**

在浏览器中打开 `index.html`，确认：
- 侧边栏显示在左侧，宽度约为屏幕 1/8
- Logo 区域显示"高昌举升机"
- 导航按钮可点击，点击后有激活状态（冰蓝高亮）
- 语言选择框显示在底部
- 主区域空白无报错

- [ ] **Step 6: 提交**

```bash
git add index.html css/styles.css css/sidebar.css js/app.js
git commit -m "feat: add sidebar navigation and page skeleton"
```

---

### Task 2: 多语言系统 (i18n)

**Files:**
- Create: `E:/MCU/高昌/测试代码/web/js/i18n.js`

- [ ] **Step 1: 创建 js/i18n.js 多语言字典和翻译函数**

```javascript
(function () {
    'use strict';

    const translations = {
        zh: {
            logo: '高昌举升机',
            nav_home: '主页',
            nav_dashboard: '仪表盘',
            nav_status: '设备状态',
            nav_alarms: '报警记录',
            nav_settings: '设置',
            home_title: '系统总览',
            motor1: '电机 1',
            motor2: '电机 2',
            height_label: '举升高度',
            health_label: '设备健康度',
            lift_count_label: '累计举升',
            system_status: '系统状态',
            alarm_info: '报警信息',
            online_status: '联机状态',
            status_idle: '空闲',
            status_rising: '上升中',
            status_falling: '下降中',
            status_sync: '同步校准中',
            status_alarm: '报警',
            status_emergency: '急停',
            health_excellent: '优秀',
            health_good: '良好',
            health_warning: '注意',
            health_critical: '维护',
            online_count: '在线立柱',
            no_alarm: '无报警',
            max_diff: '最大高度差',
            times: '次',
            mm_unit: 'mm',
            sync_error: '同步误差',
            unit_mm: 'mm',
            unit_rpm: 'RPM',
            unit_c: '°C',
        },
        en: {
            logo: 'GAOCHANG LIFT',
            nav_home: 'Home',
            nav_dashboard: 'Dashboard',
            nav_status: 'Status',
            nav_alarms: 'Alarms',
            nav_settings: 'Settings',
            home_title: 'System Overview',
            motor1: 'Motor 1',
            motor2: 'Motor 2',
            height_label: 'Lift Height',
            health_label: 'Equipment Health',
            lift_count_label: 'Total Lifts',
            system_status: 'System Status',
            alarm_info: 'Alarm Info',
            online_status: 'Online Status',
            status_idle: 'Idle',
            status_rising: 'Rising',
            status_falling: 'Falling',
            status_sync: 'Syncing',
            status_alarm: 'Alarm',
            status_emergency: 'E-Stop',
            health_excellent: 'Excellent',
            health_good: 'Good',
            health_warning: 'Warning',
            health_critical: 'Critical',
            online_count: 'Columns Online',
            no_alarm: 'No Alarms',
            max_diff: 'Max Height Diff',
            times: 'times',
            mm_unit: 'mm',
            sync_error: 'Sync Error',
            unit_mm: 'mm',
            unit_rpm: 'RPM',
            unit_c: '°C',
        },
        ru: {
            logo: 'GAOCHANG ПОДЪЁМ',
            nav_home: 'Главная',
            nav_dashboard: 'Панель',
            nav_status: 'Статус',
            nav_alarms: 'Сигналы',
            nav_settings: 'Настройки',
            home_title: 'Обзор Системы',
            motor1: 'Мотор 1',
            motor2: 'Мотор 2',
            height_label: 'Высота Подъёма',
            health_label: 'Здоровье Оборудования',
            lift_count_label: 'Всего Подъёмов',
            system_status: 'Статус Системы',
            alarm_info: 'Информация Сигнала',
            online_status: 'Онлайн Статус',
            status_idle: 'Ожидание',
            status_rising: 'Подъём',
            status_falling: 'Спуск',
            status_sync: 'Синхронизация',
            status_alarm: 'Сигнал',
            status_emergency: 'Авар. Стоп',
            health_excellent: 'Отлично',
            health_good: 'Хорошо',
            health_warning: 'Внимание',
            health_critical: 'Критично',
            online_count: 'Колонн Онлайн',
            no_alarm: 'Нет Сигналов',
            max_diff: 'Макс Разница Высоты',
            times: 'раз',
            mm_unit: 'мм',
            sync_error: 'Ошибка Синхронизации',
            unit_mm: 'мм',
            unit_rpm: 'ОБ/М',
            unit_c: '°C',
        }
    };

    let currentLang = 'zh';

    function setLanguage(lang) {
        if (!translations[lang]) return;
        currentLang = lang;
        document.documentElement.lang = lang;

        // Translate all elements with data-i18n attribute
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.dataset.i18n;
            if (translations[lang][key]) {
                el.textContent = translations[lang][key];
            }
        });

        // Update lang select
        const select = document.getElementById('langSelect');
        if (select) select.value = lang;
    }

    function t(key) {
        return translations[currentLang]?.[key] || key;
    }

    // Expose globally
    window.I18n = { setLanguage, t };
})();
```

- [ ] **Step 2: 更新 js/app.js 中的 applyLanguage 方法**

将 `js/app.js` 中的 `applyLanguage` 替换为：

```javascript
applyLanguage(lang) {
    if (window.I18n) {
        window.I18n.setLanguage(lang);
    }
}
```

- [ ] **Step 3: 验证语言切换**

打开 `index.html`，切换语言选择框，确认侧边栏文字在中文/英文/俄文之间切换。

- [ ] **Step 4: 提交**

```bash
git add js/i18n.js js/app.js
git commit -m "feat: add i18n system with zh/en/ru translations"
```

---

### Task 3: 主页视图 — 系统总览卡片

**Files:**
- Modify: `E:/MCU/高昌/测试代码/web/index.html`
- Create: `E:/MCU/高昌/测试代码/web/css/cards.css`

- [ ] **Step 1: 在 index.html 的 main-content 中添加主页视图**

在 `<main class="main-content" id="mainContent">` 内部添加：

```html
<!-- HOME VIEW -->
<section id="view-home" class="view-section">
    <h1 class="page-title" data-i18n="home_title">系统总览</h1>

    <div class="cards-grid">
        <!-- Motor Height Cards -->
        <div class="card motor-card" id="motor1-card">
            <div class="card-header">
                <span data-i18n="motor1">电机 1</span>
                <span class="status-badge" id="motor1-state">IDLE</span>
            </div>
            <div class="motor-value">
                <span class="value-number text-mono" id="motor1-height">0.0</span>
                <span class="value-unit" data-i18n="unit_mm">mm</span>
            </div>
            <div class="motor-bar">
                <div class="motor-bar-fill" id="motor1-bar" style="width: 0%"></div>
            </div>
        </div>

        <div class="card motor-card" id="motor2-card">
            <div class="card-header">
                <span data-i18n="motor2">电机 2</span>
                <span class="status-badge" id="motor2-state">IDLE</span>
            </div>
            <div class="motor-value">
                <span class="value-number text-mono" id="motor2-height">0.0</span>
                <span class="value-unit" data-i18n="unit_mm">mm</span>
            </div>
            <div class="motor-bar">
                <div class="motor-bar-fill" id="motor2-bar" style="width: 0%"></div>
            </div>
        </div>

        <!-- Health Card -->
        <div class="card health-card">
            <div class="card-header">
                <span data-i18n="health_label">设备健康度</span>
            </div>
            <div class="health-row">
                <div class="health-item">
                    <span class="health-label" data-i18n="motor1">电机 1</span>
                    <div class="health-bar">
                        <div class="health-bar-fill" id="health1-bar" style="width: 85%"></div>
                    </div>
                    <span class="health-value text-mono" id="health1-value">85%</span>
                    <span class="health-status success" id="health1-status" data-i18n="health_good">良好</span>
                </div>
                <div class="health-item">
                    <span class="health-label" data-i18n="motor2">电机 2</span>
                    <div class="health-bar">
                        <div class="health-bar-fill" id="health2-bar" style="width: 92%"></div>
                    </div>
                    <span class="health-value text-mono" id="health2-value">92%</span>
                    <span class="health-status success" id="health2-status" data-i18n="health_excellent">优秀</span>
                </div>
            </div>
            <div class="health-stats">
                <div class="health-stat">
                    <span class="stat-label text-muted" data-i18n="lift_count_label">累计举升</span>
                    <span class="stat-value text-mono" id="lift-count">1,247</span>
                    <span class="stat-unit text-muted" data-i18n="times">次</span>
                </div>
                <div class="health-stat">
                    <span class="stat-label text-muted" data-i18n="max_diff">最大高度差</span>
                    <span class="stat-value text-mono" id="height-diff">1.5</span>
                    <span class="stat-unit text-muted" data-i18n="unit_mm">mm</span>
                </div>
            </div>
        </div>

        <!-- Status Info Cards -->
        <div class="card status-card">
            <div class="status-dot" id="system-dot"></div>
            <div class="status-info">
                <span class="status-title" data-i18n="system_status">系统状态</span>
                <span class="status-text" id="system-status" data-i18n="status_idle">空闲</span>
            </div>
        </div>

        <div class="card status-card">
            <div class="status-dot warning" id="alarm-dot"></div>
            <div class="status-info">
                <span class="status-title" data-i18n="alarm_info">报警信息</span>
                <span class="status-text" id="alarm-status" data-i18n="no_alarm">无报警</span>
            </div>
        </div>

        <div class="card status-card">
            <div class="status-dot success" id="online-dot"></div>
            <div class="status-info">
                <span class="status-title" data-i18n="online_status">联机状态</span>
                <span class="status-text" id="online-status">2/2 <span data-i18n="online_count">在线立柱</span></span>
            </div>
        </div>
    </div>
</section>
```

- [ ] **Step 2: 创建 css/cards.css 卡片样式**

```css
/* ===== Page Title ===== */
.page-title {
    font-size: 20px;
    font-weight: 700;
    margin-bottom: 20px;
    color: var(--text-primary);
    letter-spacing: 0.08em;
}

/* ===== Cards Grid ===== */
.cards-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
}

/* ===== Base Card ===== */
.card {
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 20px;
    position: relative;
    overflow: hidden;
    transition: var(--transition);
}

.card:hover {
    background: var(--bg-card-hover);
    border-color: rgba(0, 212, 255, 0.15);
}

.card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent, var(--accent), transparent);
    opacity: 0;
    transition: var(--transition);
}

.card:hover::before {
    opacity: 0.6;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
    color: var(--text-secondary);
    margin-bottom: 12px;
    font-weight: 500;
}

/* ===== Motor Cards ===== */
.motor-card {
    animation: pulse-glow 3s ease-in-out infinite;
}

.motor-value {
    display: flex;
    align-items: baseline;
    gap: 6px;
    margin-bottom: 16px;
}

.value-number {
    font-size: 48px;
    font-weight: 700;
    font-family: var(--font-display);
    color: var(--accent);
    line-height: 1;
    text-shadow: 0 0 20px var(--accent-glow);
}

.value-unit {
    font-size: 16px;
    color: var(--text-secondary);
    font-weight: 400;
}

/* Motor progress bar */
.motor-bar {
    height: 6px;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 3px;
    overflow: hidden;
}

.motor-bar-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--accent), #0088cc);
    border-radius: 3px;
    transition: width 0.8s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 0 0 8px var(--accent-glow);
}

/* Status badge */
.status-badge {
    font-size: 10px;
    padding: 3px 8px;
    border-radius: 4px;
    background: var(--accent-dim);
    color: var(--accent);
    font-family: var(--font-display);
    font-weight: 600;
    letter-spacing: 0.05em;
}

/* ===== Health Card ===== */
.health-card {
    grid-column: span 2;
}

.health-row {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 16px;
}

.health-item {
    display: flex;
    align-items: center;
    gap: 12px;
}

.health-label {
    font-size: 12px;
    color: var(--text-secondary);
    min-width: 50px;
}

.health-bar {
    flex: 1;
    height: 4px;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 2px;
    overflow: hidden;
}

.health-bar-fill {
    height: 100%;
    border-radius: 2px;
    transition: width 0.6s ease, background 0.3s ease;
}

.health-bar-fill.success { background: var(--success); }
.health-bar-fill.warning { background: var(--warning); }
.health-bar-fill.danger { background: var(--danger); }

.health-value {
    font-size: 16px;
    font-weight: 600;
    color: var(--text-primary);
    min-width: 40px;
    text-align: right;
}

.health-status {
    font-size: 11px;
    min-width: 40px;
}

.health-stats {
    display: flex;
    gap: 24px;
    padding-top: 12px;
    border-top: 1px solid var(--border);
}

.health-stat {
    display: flex;
    align-items: baseline;
    gap: 4px;
}

.stat-label {
    font-size: 11px;
}

.stat-value {
    font-size: 18px;
    font-weight: 700;
    color: var(--text-primary);
}

.stat-unit {
    font-size: 11px;
}

/* ===== Status Cards ===== */
.status-card {
    display: flex;
    align-items: center;
    gap: 14px;
}

.status-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: var(--text-muted);
    flex-shrink: 0;
}

.status-dot.success { background: var(--success); box-shadow: 0 0 8px rgba(0, 230, 118, 0.4); }
.status-dot.warning { background: var(--warning); box-shadow: 0 0 8px rgba(255, 171, 0, 0.4); }
.status-dot.danger { background: var(--danger); box-shadow: 0 0 8px rgba(255, 23, 68, 0.4); }

.status-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.status-title {
    font-size: 11px;
    color: var(--text-muted);
}

.status-text {
    font-size: 14px;
    font-weight: 500;
    color: var(--text-primary);
}
```

- [ ] **Step 3: 验证主页卡片**

打开 `index.html`，确认：
- 3 列卡片布局
- 两个电机高度卡片显示大数字和进度条
- 健康度卡片跨 2 列，显示进度条和百分比
- 3 个状态信息小卡片
- 卡片有 hover 效果和顶部冰蓝光线

- [ ] **Step 4: 提交**

```bash
git add index.html css/cards.css
git commit -m "feat: add home view with motor, health, and status cards"
```

---

### Task 4: 数据模型 + 实时模拟更新

**Files:**
- Create: `E:/MCU/高昌/测试代码/web/js/data.js`
- Create: `E:/MCU/高昌/测试代码/web/js/updates.js`

- [ ] **Step 1: 创建 js/data.js 数据模型**

```javascript
(function () {
    'use strict';

    const SystemState = {
        IDLE: 0,
        RISING: 1,
        FALLING: 2,
        SYNC_WAIT: 3,
        ALARM: 4,
        EMERGENCY_STOP: 5,
    };

    const AlarmCode = {
        NONE: 0,
        STALL_COL1: 1,
        STALL_COL2: 2,
        SYNC_OVER: 3,
        ANTI_COLLISION: 4,
        NUT_WEAR: 5,
    };

    // Simulated live data
    const LiveData = {
        motor1: {
            height: 120.0,    // mm
            max_height: 200,
            health: 85,
            direction: 0,     // 0=idle, 1=up, 2=down
            state: SystemState.IDLE,
        },
        motor2: {
            height: 118.5,
            max_height: 200,
            health: 92,
            direction: 0,
            state: SystemState.IDLE,
        },
        systemState: SystemState.IDLE,
        alarmCode: AlarmCode.NONE,
        liftCount: 1247,
        onlineCount: 2,
    };

    const StateLabels = {
        [SystemState.IDLE]: 'status_idle',
        [SystemState.RISING]: 'status_rising',
        [SystemState.FALLING]: 'status_falling',
        [SystemState.SYNC_WAIT]: 'status_sync',
        [SystemState.ALARM]: 'status_alarm',
        [SystemState.EMERGENCY_STOP]: 'status_emergency',
    };

    function getHealthStatus(health) {
        if (health >= 90) return { label: 'health_excellent', cls: 'success' };
        if (health >= 70) return { label: 'health_good', cls: 'success' };
        if (health >= 40) return { label: 'health_warning', cls: 'warning' };
        return { label: 'health_critical', cls: 'danger' };
    }

    window.LiveData = LiveData;
    window.SystemState = SystemState;
    window.StateLabels = StateLabels;
    window.getHealthStatus = getHealthStatus;
})();
```

- [ ] **Step 2: 创建 js/updates.js 模拟数据更新**

```javascript
(function () {
    'use strict';

    // State machine for simulation: cycle through idle -> rising -> falling -> idle
    let simPhase = 'idle';
    let simTimer = 0;

    function simulateData() {
        simTimer++;

        // Phase transitions
        if (simPhase === 'idle' && simTimer > 30) {
            simPhase = 'rising';
            simTimer = 0;
            LiveData.systemState = SystemState.RISING;
            LiveData.motor1.direction = 1;
            LiveData.motor2.direction = 1;
        } else if (simPhase === 'rising' && simTimer > 80) {
            simPhase = 'idle';
            simTimer = 0;
            LiveData.systemState = SystemState.IDLE;
            LiveData.motor1.direction = 0;
            LiveData.motor2.direction = 0;
        } else if (simPhase === 'idle' && simTimer > 20 && simTimer <= 30) {
            // Still idle
        }

        // Update motor heights during rising phase
        if (simPhase === 'rising') {
            LiveData.motor1.height = Math.min(LiveData.motor1.height + 0.8, LiveData.motor1.max_height);
            LiveData.motor2.height = Math.min(LiveData.motor2.height + 0.7 + Math.random() * 0.2, LiveData.motor2.max_height);
        }

        // Slight random drift for realism
        if (simPhase === 'idle') {
            LiveData.motor1.height += (Math.random() - 0.5) * 0.2;
            LiveData.motor2.height += (Math.random() - 0.5) * 0.2;
        }

        // Clamp heights
        LiveData.motor1.height = Math.max(0, LiveData.motor1.height);
        LiveData.motor2.height = Math.max(0, LiveData.motor2.height);

        // Gradual health decay (very slow, for visual effect)
        if (simTimer % 500 === 0) {
            LiveData.motor1.health = Math.max(60, LiveData.motor1.health - 0.5);
            LiveData.motor2.health = Math.max(70, LiveData.motor2.health - 0.3);
        }

        // Increment lift count periodically
        if (simPhase === 'idle' && simTimer === 1) {
            LiveData.liftCount++;
        }
    }

    function updateUI() {
        const { motor1, motor2, systemState, liftCount } = LiveData;

        // Motor heights
        const h1El = document.getElementById('motor1-height');
        const h2El = document.getElementById('motor2-height');
        if (h1El) h1El.textContent = motor1.height.toFixed(1);
        if (h2El) h2El.textContent = motor2.height.toFixed(1);

        // Motor bars
        const b1El = document.getElementById('motor1-bar');
        const b2El = document.getElementById('motor2-bar');
        if (b1El) b1El.style.width = (motor1.height / motor1.max_height * 100) + '%';
        if (b2El) b2El.style.width = (motor2.height / motor2.max_height * 100) + '%';

        // Motor state badges
        const s1El = document.getElementById('motor1-state');
        const s2El = document.getElementById('motor2-state');
        if (s1El) s1El.textContent = StateLabels[motor1.state] || 'IDLE';
        if (s2El) s2El.textContent = StateLabels[motor2.state] || 'IDLE';

        // Health bars
        const health1 = getHealthStatus(motor1.health);
        const health2 = getHealthStatus(motor2.health);

        const hb1 = document.getElementById('health1-bar');
        const hb2 = document.getElementById('health2-bar');
        const hv1 = document.getElementById('health1-value');
        const hv2 = document.getElementById('health2-value');
        const hs1 = document.getElementById('health1-status');
        const hs2 = document.getElementById('health2-status');

        if (hb1) {
            hb1.style.width = motor1.health + '%';
            hb1.className = 'health-bar-fill ' + health1.cls;
        }
        if (hb2) {
            hb2.style.width = motor2.health + '%';
            hb2.className = 'health-bar-fill ' + health2.cls;
        }
        if (hv1) hv1.textContent = Math.round(motor1.health) + '%';
        if (hv2) hv2.textContent = Math.round(motor2.health) + '%';
        if (hs1) {
            hs1.textContent = I18n.t(health1.label);
            hs1.className = 'health-status ' + health1.cls;
        }
        if (hs2) {
            hs2.textContent = I18n.t(health2.label);
            hs2.className = 'health-status ' + health2.cls;
        }

        // Lift count
        const lcEl = document.getElementById('lift-count');
        if (lcEl) lcEl.textContent = liftCount.toLocaleString();

        // Height diff
        const diff = Math.abs(motor1.height - motor2.height);
        const diffEl = document.getElementById('height-diff');
        if (diffEl) diffEl.textContent = diff.toFixed(1);

        // System status
        const sysStatus = document.getElementById('system-status');
        const sysDot = document.getElementById('system-dot');
        if (sysStatus) {
            const key = StateLabels[systemState];
            sysStatus.textContent = I18n.t(key);
        }
        if (sysDot) {
            sysDot.className = 'status-dot';
            if (systemState === SystemState.IDLE) sysDot.classList.add('warning');
            else if (systemState === SystemState.ALARM || systemState === SystemState.EMERGENCY_STOP) sysDot.classList.add('danger');
            else sysDot.classList.add('success');
        }
    }

    function tick() {
        simulateData();
        updateUI();
    }

    // Start simulation at 100ms intervals
    window.startSimulation = function () {
        setInterval(tick, 100);
    };
})();
```

- [ ] **Step 3: 更新 js/app.js 启动模拟**

在 `App.init()` 的最后添加：

```javascript
if (window.startSimulation) {
    window.startSimulation();
}
```

- [ ] **Step 4: 验证数据动态更新**

打开 `index.html`，确认：
- 电机高度数字每秒变化（上升阶段）
- 进度条平滑动画
- 健康度进度条颜色正确（绿色/黄色/红色）
- 系统状态在"空闲"和"上升中"之间循环

- [ ] **Step 5: 提交**

```bash
git add js/data.js js/updates.js js/app.js
git commit -m "feat: add simulated real-time data updates"
```

---

### Task 5: 仪表盘视图 + 设备状态视图 + 报警视图

**Files:**
- Modify: `E:/MCU/高昌/测试代码/web/index.html`
- Modify: `E:/MCU/高昌/测试代码/web/css/cards.css`

- [ ] **Step 1: 在 index.html 的 main-content 中添加仪表盘视图**

在 `</main>` 前，`view-home` 之后添加：

```html
<!-- DASHBOARD VIEW -->
<section id="view-dashboard" class="view-section hidden">
    <h1 class="page-title" data-i18n="nav_dashboard">仪表盘</h1>
    <div class="cards-grid">
        <!-- Dual Motor Ring Gauges -->
        <div class="card gauge-card">
            <div class="gauge-container">
                <svg class="gauge-svg" viewBox="0 0 200 200">
                    <circle class="gauge-bg" cx="100" cy="100" r="80" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="10"/>
                    <circle class="gauge-fill" id="gauge1-fill" cx="100" cy="100" r="80" fill="none" stroke="var(--accent)" stroke-width="10"
                            stroke-dasharray="502.65" stroke-dashoffset="502.65" stroke-linecap="round"
                            transform="rotate(-90 100 100)"/>
                </svg>
                <div class="gauge-center">
                    <span class="gauge-value text-mono" id="gauge1-value">0</span>
                    <span class="gauge-unit text-muted">mm</span>
                </div>
            </div>
            <div class="gauge-label" data-i18n="motor1">电机 1</div>
        </div>

        <div class="card gauge-card">
            <div class="gauge-container">
                <svg class="gauge-svg" viewBox="0 0 200 200">
                    <circle class="gauge-bg" cx="100" cy="100" r="80" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="10"/>
                    <circle class="gauge-fill" id="gauge2-fill" cx="100" cy="100" r="80" fill="none" stroke="var(--accent)" stroke-width="10"
                            stroke-dasharray="502.65" stroke-dashoffset="502.65" stroke-linecap="round"
                            transform="rotate(-90 100 100)"/>
                </svg>
                <div class="gauge-center">
                    <span class="gauge-value text-mono" id="gauge2-value">0</span>
                    <span class="gauge-unit text-muted">mm</span>
                </div>
            </div>
            <div class="gauge-label" data-i18n="motor2">电机 2</div>
        </div>

        <!-- Sync Error Display -->
        <div class="card sync-card">
            <div class="card-header">
                <span data-i18n="sync_error">同步误差</span>
            </div>
            <div class="sync-value">
                <span class="value-number text-mono" id="sync-value">0.0</span>
                <span class="value-unit" data-i18n="unit_mm">mm</span>
            </div>
            <div class="sync-indicator" id="sync-indicator"></div>
        </div>
    </div>
</section>

<!-- STATUS VIEW -->
<section id="view-status" class="view-section hidden">
    <h1 class="page-title" data-i18n="nav_status">设备状态</h1>
    <div class="cards-grid">
        <div class="card detail-card">
            <div class="detail-title" data-i18n="motor1">电机 1</div>
            <div class="detail-row">
                <span class="detail-label text-muted">高度</span>
                <span class="detail-value text-mono" id="detail-h1">0.0 mm</span>
            </div>
            <div class="detail-row">
                <span class="detail-label text-muted">健康度</span>
                <span class="detail-value" id="detail-health1">85%</span>
            </div>
            <div class="detail-row">
                <span class="detail-label text-muted">方向</span>
                <span class="detail-value" id="detail-dir1">—</span>
            </div>
            <div class="detail-row">
                <span class="detail-label text-muted">状态</span>
                <span class="detail-value" id="detail-state1">IDLE</span>
            </div>
        </div>
        <div class="card detail-card">
            <div class="detail-title" data-i18n="motor2">电机 2</div>
            <div class="detail-row">
                <span class="detail-label text-muted">高度</span>
                <span class="detail-value text-mono" id="detail-h2">0.0 mm</span>
            </div>
            <div class="detail-row">
                <span class="detail-label text-muted">健康度</span>
                <span class="detail-value" id="detail-health2">92%</span>
            </div>
            <div class="detail-row">
                <span class="detail-label text-muted">方向</span>
                <span class="detail-value" id="detail-dir2">—</span>
            </div>
            <div class="detail-row">
                <span class="detail-label text-muted">状态</span>
                <span class="detail-value" id="detail-state2">IDLE</span>
            </div>
        </div>
    </div>
</section>

<!-- ALARMS VIEW -->
<section id="view-alarms" class="view-section hidden">
    <h1 class="page-title" data-i18n="nav_alarms">报警记录</h1>
    <div class="alarm-list" id="alarmList">
        <!-- Populated by JS -->
    </div>
</section>

<!-- SETTINGS VIEW -->
<section id="view-settings" class="view-section hidden">
    <h1 class="page-title" data-i18n="nav_settings">设置</h1>
    <div class="cards-grid">
        <div class="card setting-card">
            <div class="card-header">
                <span>语言 / Language</span>
            </div>
            <p class="text-muted" style="font-size: 13px; margin-top: 8px;">
                使用左侧边栏底部的语言选择器切换界面语言。<br>
                Use the language selector at the bottom of the sidebar.
            </p>
        </div>
        <div class="card setting-card">
            <div class="card-header">
                <span>数据模拟 / Data Simulation</span>
            </div>
            <p class="text-muted" style="font-size: 13px; margin-top: 8px;">
                当前为演示模式，数据每 100ms 自动更新。<br>
                Demo mode: data updates automatically every 100ms.
            </p>
        </div>
    </div>
</section>
```

- [ ] **Step 2: 在 css/cards.css 末尾添加仪表盘/状态/报警样式**

```css
/* ===== Gauge Cards ===== */
.gauge-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 24px;
}

.gauge-container {
    position: relative;
    width: 180px;
    height: 180px;
}

.gauge-svg {
    width: 100%;
    height: 100%;
}

.gauge-fill {
    transition: stroke-dashoffset 0.8s cubic-bezier(0.4, 0, 0.2, 1);
    filter: drop-shadow(0 0 6px var(--accent-glow));
}

.gauge-center {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
}

.gauge-value {
    display: block;
    font-size: 32px;
    font-weight: 700;
    color: var(--accent);
    line-height: 1;
}

.gauge-unit {
    font-size: 12px;
    color: var(--text-secondary);
    margin-left: 2px;
}

.gauge-label {
    margin-top: 12px;
    font-size: 13px;
    color: var(--text-secondary);
    font-weight: 500;
}

/* ===== Sync Card ===== */
.sync-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 200px;
}

.sync-value {
    display: flex;
    align-items: baseline;
    gap: 4px;
}

.sync-indicator {
    width: 60%;
    height: 3px;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 2px;
    margin-top: 16px;
    overflow: hidden;
    position: relative;
}

.sync-indicator::after {
    content: '';
    position: absolute;
    left: 50%;
    top: 0;
    height: 100%;
    width: 4px;
    background: var(--accent);
    border-radius: 2px;
    transform: translateX(-50%);
    transition: var(--transition);
    box-shadow: 0 0 6px var(--accent-glow);
}

/* ===== Detail Card ===== */
.detail-card {
    padding: 24px;
}

.detail-title {
    font-family: var(--font-display);
    font-size: 16px;
    font-weight: 600;
    color: var(--accent);
    margin-bottom: 16px;
    padding-bottom: 8px;
    border-bottom: 1px solid var(--border);
}

.detail-row {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    border-bottom: 1px solid var(--border);
}

.detail-row:last-child {
    border-bottom: none;
}

.detail-label {
    font-size: 13px;
}

.detail-value {
    font-size: 14px;
    font-weight: 500;
    font-family: var(--font-display);
    color: var(--text-primary);
}

/* ===== Alarm List ===== */
.alarm-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.alarm-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 16px;
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    transition: var(--transition);
}

.alarm-item:hover {
    background: var(--bg-card-hover);
}

.alarm-item.critical {
    border-left: 3px solid var(--danger);
}

.alarm-item.warning {
    border-left: 3px solid var(--warning);
}

.alarm-icon {
    font-size: 18px;
}

.alarm-content {
    flex: 1;
}

.alarm-code {
    font-size: 13px;
    font-weight: 500;
    color: var(--text-primary);
}

.alarm-desc {
    font-size: 11px;
    color: var(--text-secondary);
    margin-top: 2px;
}

.alarm-time {
    font-size: 11px;
    font-family: var(--font-display);
    color: var(--text-muted);
}

/* ===== Setting Card ===== */
.setting-card {
    padding: 20px;
}
```

- [ ] **Step 3: 更新 js/updates.js 增加仪表盘和状态视图的 UI 更新**

在 `updateUI()` 函数末尾添加：

```javascript
        // Dashboard gauge update
        const circumference = 502.65;
        const g1Fill = document.getElementById('gauge1-fill');
        const g2Fill = document.getElementById('gauge2-fill');
        const g1Value = document.getElementById('gauge1-value');
        const g2Value = document.getElementById('gauge2-value');

        if (g1Fill) {
            const pct1 = motor1.height / motor1.max_height;
            g1Fill.style.strokeDashoffset = circumference * (1 - pct1);
        }
        if (g2Fill) {
            const pct2 = motor2.height / motor2.max_height;
            g2Fill.style.strokeDashoffset = circumference * (1 - pct2);
        }
        if (g1Value) g1Value.textContent = motor1.height.toFixed(1);
        if (g2Value) g2Value.textContent = motor2.height.toFixed(1);

        // Sync value
        const diff = Math.abs(motor1.height - motor2.height);
        const svEl = document.getElementById('sync-value');
        if (svEl) svEl.textContent = diff.toFixed(1);

        // Detail view update
        const dirLabels = { 0: '—', 1: '↑ ↑', 2: '↓ ↓' };
        const dh1 = document.getElementById('detail-h1');
        const dh2 = document.getElementById('detail-h2');
        const dhealth1 = document.getElementById('detail-health1');
        const dhealth2 = document.getElementById('detail-health2');
        const ddir1 = document.getElementById('detail-dir1');
        const ddir2 = document.getElementById('detail-dir2');
        const dstate1 = document.getElementById('detail-state1');
        const dstate2 = document.getElementById('detail-state2');

        if (dh1) dh1.textContent = motor1.height.toFixed(1) + ' mm';
        if (dh2) dh2.textContent = motor2.height.toFixed(1) + ' mm';
        if (dhealth1) dhealth1.textContent = Math.round(motor1.health) + '%';
        if (dhealth2) dhealth2.textContent = Math.round(motor2.health) + '%';
        if (ddir1) ddir1.textContent = dirLabels[motor1.direction];
        if (ddir2) ddir2.textContent = dirLabels[motor2.direction];
        if (dstate1) dstate1.textContent = StateLabels[motor1.state] || 'IDLE';
        if (dstate2) dstate2.textContent = StateLabels[motor2.state] || 'IDLE';
```

- [ ] **Step 4: 验证所有视图**

打开 `index.html`，点击侧边栏各导航按钮，确认：
- 仪表盘：环形仪表动画更新，同步误差显示
- 设备状态：两列详细参数表
- 报警记录：空列表（下一步添加模拟报警）
- 设置：静态说明

- [ ] **Step 5: 提交**

```bash
git add index.html css/cards.css js/updates.js
git commit -m "feat: add dashboard, status, alarms, and settings views"
```

---

### Task 6: 模拟报警数据 + 最终打磨

**Files:**
- Modify: `E:/MCU/高昌/测试代码/web/js/data.js`
- Modify: `E:/MCU/高昌/测试代码/web/js/updates.js`

- [ ] **Step 1: 在 js/data.js 中添加模拟报警数据**

在 `LiveData` 对象之后添加：

```javascript
    // Simulated alarm log
    const AlarmLog = [
        { code: 'ALARM_STALL_COL1', desc_zh: '柱1 堵转', desc_en: 'Column 1 Stall', desc_ru: 'Колонна 1 Заедание', time: '2026-04-25 08:23:15', severity: 'critical' },
        { code: 'ALARM_SYNC_OVER', desc_zh: '同步误差超限', desc_en: 'Sync Error Over Limit', desc_ru: 'Ошибка Синхронизации', time: '2026-04-24 14:07:42', severity: 'warning' },
        { code: 'ALARM_NUT_WEAR', desc_zh: '螺母磨损检测', desc_en: 'Nut Wear Detected', desc_ru: 'Износ Гайки', time: '2026-04-23 09:51:30', severity: 'warning' },
        { code: 'ALARM_ANTI_COLLISION', desc_zh: '防碰杆触发', desc_en: 'Anti-Collision Triggered', desc_ru: 'Анти-Коллизия', time: '2026-04-22 16:33:08', severity: 'critical' },
    ];

    window.AlarmLog = AlarmLog;
```

- [ ] **Step 2: 在 js/updates.js 末尾添加报警列表渲染函数**

在 `window.startSimulation` 之前添加：

```javascript
    function renderAlarms() {
        const container = document.getElementById('alarmList');
        if (!container) return;

        container.innerHTML = '';
        AlarmLog.forEach(alarm => {
            const div = document.createElement('div');
            div.className = `alarm-item ${alarm.severity}`;
            div.innerHTML = `
                <span class="alarm-icon">${alarm.severity === 'critical' ? '🔴' : '🟡'}</span>
                <div class="alarm-content">
                    <div class="alarm-code">${alarm.code}</div>
                    <div class="alarm-desc">${alarm.desc_zh} / ${alarm.desc_en}</div>
                </div>
                <span class="alarm-time">${alarm.time}</span>
            `;
            container.appendChild(div);
        });
    }

    // Call renderAlarms on first load
    setTimeout(renderAlarms, 100);
```

- [ ] **Step 3: 最终验证**

打开 `index.html` 完整测试：
1. 主页：所有卡片显示正常，数据动态更新
2. 侧边栏切换视图流畅，有 fade-in 动画
3. 语言切换：中→英→俄，所有带 `data-i18n` 的元素正确翻译
4. 仪表盘：环形仪表随高度动画
5. 报警记录：4 条模拟报警显示正确样式
6. 整体视觉效果符合特斯拉深色科技风

- [ ] **Step 4: 提交**

```bash
git add js/data.js js/updates.js
git commit -m "feat: add alarm log and final polish"
```

---
