# 1024x600 HMI 精简版设计

## 目标
将现有控制面板精简为适合 1024x600 触摸屏的单页布局，为后续 LVGL 移植做准备。

## 设计决策
- 单页显示，6 个核心数据块（2x3 网格）
- 可折叠窄侧边栏（60px ↔ 0px）
- 全部字体改为 Microsoft YaHei
- 去除毛玻璃、SVG、复杂阴影等 LVGL 不支持的效果
- 布局使用固定像素尺寸

## 实现清单

### 1. 重写 index.html
- 移除多视图结构，改为单页布局
- 主页面 6 个数据块（电机1、电机2、误差、系统状态、连接状态、报警）
- 侧边栏改为 60px 窄栏 + 折叠按钮

### 2. 重写 css/styles.css
- 容器固定 1024x600
- 字体全部改为 Microsoft YaHei
- 去除 backdrop-filter、box-shadow 多层效果
- 简化动画，只用 opacity + transform

### 3. 重写 css/sidebar.css
- 60px 窄侧边栏
- 竖排图标 + 语言选择器 + 折叠按钮
- 折叠动画

### 4. 重写 css/cards.css
- 2x3 网格布局
- 大数字 + 进度条 + 状态指示灯
- 去除 SVG 和 conic-gradient 之外的复杂装饰

### 5. 简化 js/data.js
- 保留 LiveData、SystemState、StateLabels
- 保留 getHealthStatus

### 6. 简化 js/updates.js
- 只更新主页 6 个数据块
- 保留模拟数据逻辑
- 移除仪表盘/详情视图的 UI 更新

### 7. 简化 js/app.js
- 添加侧边栏折叠/展开
- 保留语言切换
- 移除多视图切换逻辑

### 8. 简化 js/i18n.js
- 精简翻译键，只保留需要的
