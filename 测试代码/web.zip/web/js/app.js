(function () {
    'use strict';

    const App = {
        targetHeightM: 1.20,
        stepM: 0.05,
        maxM: 2.00,
        minM: 0.00,
        demoMode: true,
        _numpadBuffer: '',

        init() {
            this.bindMenu();
            this.bindViews();
            this.bindHeightControls();
            this.bindSettings();
            this.bindLanguage();
            this.bindConfirm();
            this.bindNumpad();
            this.applyLanguage(localStorage.getItem('app-lang') || 'zh');
            this.updateTargetDisplay();
            if (window.startSimulation) {
                window.startSimulation();
            }
        },

        // Menu
        bindMenu() {
            const btn = document.getElementById('menuBtn');
            const overlay = document.getElementById('menuOverlay');
            const items = document.querySelectorAll('.menu-item');

            btn.addEventListener('click', () => {
                overlay.classList.add('visible');
            });

            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) overlay.classList.remove('visible');
            });

            items.forEach(item => {
                item.addEventListener('click', () => {
                    const viewId = item.dataset.view;
                    this.switchView(viewId);
                    overlay.classList.remove('visible');
                });
            });
        },

        // View switching with animation
        switchView(viewId) {
            const currentView = document.querySelector('.view.active');
            const targetView = document.getElementById(viewId);

            if (currentView === targetView) return;

            if (currentView) {
                currentView.classList.remove('active', 'entering');
                currentView.classList.add('leaving');
                currentView.addEventListener('animationend', () => {
                    currentView.classList.remove('leaving');
                    if (targetView) {
                        targetView.classList.add('active', 'entering');
                        targetView.addEventListener('animationend', () => {
                            targetView.classList.remove('entering');
                        }, { once: true });
                    }
                }, { once: true });
            } else {
                if (targetView) {
                    targetView.classList.add('active', 'entering');
                    targetView.addEventListener('animationend', () => {
                        targetView.classList.remove('entering');
                    }, { once: true });
                }
            }
        },

        bindViews() {},

        // Height controls
        bindHeightControls() {
            const minusBtn = document.getElementById('heightMinus');
            const plusBtn = document.getElementById('heightPlus');
            const targetDisplay = document.getElementById('targetDisplay');
            const confirmBtn = document.getElementById('confirmBtn');
            const stepBtns = document.querySelectorAll('.step-btn');
            const sliderThumb = document.getElementById('sliderThumb');
            const sliderTrack = document.querySelector('.slider-track');
            const sliderBubble = document.getElementById('sliderBubble');

            // Long press for +/- buttons
            this._setupLongPress(minusBtn, () => {
                this.targetHeightM = Math.max(this.minM, this.targetHeightM - this.stepM);
                this.updateTargetDisplay();
            });

            this._setupLongPress(plusBtn, () => {
                this.targetHeightM = Math.min(this.maxM, this.targetHeightM + this.stepM);
                this.updateTargetDisplay();
            });

            // Click target to open numpad
            targetDisplay.addEventListener('click', () => {
                this.openNumpad();
            });

            // Step selector
            stepBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    stepBtns.forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                    this.stepM = parseFloat(btn.dataset.step);
                });
            });

            // Track click to jump
            if (sliderTrack) {
                sliderTrack.addEventListener('click', (e) => {
                    if (e.target.classList.contains('slider-thumb') || sliderBubble?.contains(e.target)) return;
                    this.handleSliderMove(e);
                });
            }

            // Slider drag with bubble
            let dragging = false;
            const startDrag = (e) => {
                e.preventDefault();
                dragging = true;
                if (sliderBubble) sliderBubble.classList.add('visible');
                this.handleSliderMove(e);
            };
            const moveDrag = (e) => {
                if (dragging) {
                    e.preventDefault();
                    this.handleSliderMove(e);
                }
            };
            const endDrag = () => {
                dragging = false;
                if (sliderBubble) sliderBubble.classList.remove('visible');
            };

            sliderThumb.addEventListener('mousedown', startDrag);
            sliderThumb.addEventListener('touchstart', startDrag);
            document.addEventListener('mousemove', moveDrag);
            document.addEventListener('touchmove', moveDrag);
            document.addEventListener('mouseup', endDrag);
            document.addEventListener('touchend', endDrag);

            // Confirm button
            confirmBtn.addEventListener('click', () => {
                this.showConfirm();
            });
        },

        handleSliderMove(e) {
            const track = document.querySelector('.slider-track');
            if (!track) return;
            const rect = track.getBoundingClientRect();
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            let pct = (clientX - rect.left) / rect.width;
            pct = Math.max(0, Math.min(1, pct));
            this.targetHeightM = this.minM + pct * (this.maxM - this.minM);
            this.targetHeightM = Math.round(this.targetHeightM * 100) / 100;
            this.updateTargetDisplay();

            const bubble = document.getElementById('sliderBubble');
            if (bubble) {
                bubble.textContent = this.targetHeightM.toFixed(2) + 'm';
            }
        },

        _setupLongPress(btn, onAction) {
            let longPressTimer = null;
            let repeatTimer = null;
            let hasTriggeredLongPress = false;

            const start = (e) => {
                e.preventDefault();
                hasTriggeredLongPress = false;
                longPressTimer = setTimeout(() => {
                    hasTriggeredLongPress = true;
                    onAction();
                    repeatTimer = setInterval(onAction, 150);
                }, 500);
            };

            const end = () => {
                clearTimeout(longPressTimer);
                clearInterval(repeatTimer);
                if (!hasTriggeredLongPress) {
                    onAction();
                }
                hasTriggeredLongPress = false;
            };

            const cancel = () => {
                clearTimeout(longPressTimer);
                clearInterval(repeatTimer);
                hasTriggeredLongPress = false;
            };

            btn.addEventListener('mousedown', start);
            btn.addEventListener('touchstart', start, { passive: false });
            btn.addEventListener('mouseup', end);
            btn.addEventListener('mouseleave', cancel);
            btn.addEventListener('touchend', end);
            btn.addEventListener('touchcancel', cancel);
        },

        updateTargetDisplay() {
            document.getElementById('target-height-val').textContent = this.targetHeightM.toFixed(2);
            document.getElementById('confirmValue').textContent = this.targetHeightM.toFixed(2) + ' m';
            const pct = (this.targetHeightM - this.minM) / (this.maxM - this.minM) * 100;
            document.getElementById('sliderFill').style.width = pct + '%';
            document.getElementById('sliderThumb').style.left = pct + '%';
        },

        // Settings
        bindSettings() {
            const toggle = document.getElementById('demoToggle');
            toggle.addEventListener('click', () => {
                this.demoMode = !this.demoMode;
                toggle.classList.toggle('on', this.demoMode);
            });
            toggle.classList.add('on');

            const segBtns = document.querySelectorAll('.seg-btn');
            segBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    segBtns.forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                });
            });
        },

        // Language drawer
        bindLanguage() {
            const langBtn = document.getElementById('langDrawerBtn');
            const overlay = document.getElementById('langDrawerOverlay');
            const options = document.querySelectorAll('.lang-option');

            langBtn.addEventListener('click', () => {
                overlay.classList.add('visible');
            });

            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) overlay.classList.remove('visible');
            });

            options.forEach(opt => {
                opt.addEventListener('click', () => {
                    this.applyLanguage(opt.dataset.lang);
                    overlay.classList.remove('visible');
                });
            });
        },

        applyLanguage(lang) {
            if (window.I18n) {
                window.I18n.setLanguage(lang);
            }
            localStorage.setItem('app-lang', lang);
        },

        // Confirm dialog
        bindConfirm() {
            const overlay = document.getElementById('confirmOverlay');
            const cancelBtn = document.getElementById('confirmCancel');
            const okBtn = document.getElementById('confirmOk');

            cancelBtn.addEventListener('click', () => {
                overlay.classList.remove('visible');
            });

            okBtn.addEventListener('click', () => {
                overlay.classList.remove('visible');
            });

            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) overlay.classList.remove('visible');
            });
        },

        showConfirm() {
            document.getElementById('confirmValue').textContent = this.targetHeightM.toFixed(2) + ' m';
            document.getElementById('confirmOverlay').classList.add('visible');
        },

        // Numpad
        bindNumpad() {
            const overlay = document.getElementById('numpadOverlay');
            const display = document.getElementById('numpadValue');
            const closeBtn = document.getElementById('numpadClose');
            const keys = document.querySelectorAll('.numpad-key');

            this._numpadBuffer = '';

            closeBtn.addEventListener('click', () => {
                overlay.classList.remove('visible');
            });
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) overlay.classList.remove('visible');
            });

            keys.forEach(key => {
                key.addEventListener('click', () => {
                    this._handleNumpadKey(key.dataset.key, display, overlay);
                });
            });
        },

        _handleNumpadKey(action, display, overlay) {
            if (action === 'confirm') {
                const val = parseFloat(this._numpadBuffer || '0');
                if (!isNaN(val) && val >= this.minM && val <= this.maxM) {
                    this.targetHeightM = Math.round(val * 100) / 100;
                    this.updateTargetDisplay();
                }
                overlay.classList.remove('visible');
                this._numpadBuffer = '';
                return;
            }
            if (action === 'backspace') {
                this._numpadBuffer = this._numpadBuffer.slice(0, -1);
            } else if (action === 'clear') {
                this._numpadBuffer = '';
            } else if (action === '.') {
                if (!this._numpadBuffer.includes('.')) {
                    this._numpadBuffer += '.';
                }
            } else {
                const parts = this._numpadBuffer.split('.');
                if (parts[1] !== undefined && parts[1].length >= 2) return;
                if (!this._numpadBuffer.includes('.') && parts[0].length >= 2) {
                    this._numpadBuffer += '.';
                }
                this._numpadBuffer += action;
            }
            if (this._numpadBuffer === '' || this._numpadBuffer === '.') {
                display.textContent = '0.00';
            } else {
                const v = parseFloat(this._numpadBuffer);
                if (!isNaN(v)) {
                    display.textContent = v.toFixed(2);
                }
            }
        },

        openNumpad() {
            this._numpadBuffer = this.targetHeightM.toFixed(2);
            document.getElementById('numpadValue').textContent = this._numpadBuffer;
            document.getElementById('numpadOverlay').classList.add('visible');
        }
    };

    document.addEventListener('DOMContentLoaded', () => App.init());
    window.App = App;
})();
