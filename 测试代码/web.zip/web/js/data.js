(function () {
    'use strict';

    const MAX_HEIGHT_M = 2.00;

    const SystemState = {
        IDLE: 0,
        RISING: 1,
        FALLING: 2,
        ALARM: 3,
    };

    const LiveData = {
        motor1: {
            heightMm: 120.0,
            maxHeightMm: 200.0,
            state: SystemState.IDLE,
        },
        motor2: {
            heightMm: 118.5,
            maxHeightMm: 200.0,
            state: SystemState.IDLE,
        },
        systemState: SystemState.IDLE,
        onlineCount: 2,
        hasAlarm: false,
    };

    const StateLabels = {
        [SystemState.IDLE]: 'status_idle',
        [SystemState.RISING]: 'status_rising',
        [SystemState.FALLING]: 'status_falling',
        [SystemState.ALARM]: 'status_alarm',
    };

    window.LiveData = LiveData;
    window.SystemState = SystemState;
    window.StateLabels = StateLabels;
    window.MAX_HEIGHT_M = MAX_HEIGHT_M;
})();
