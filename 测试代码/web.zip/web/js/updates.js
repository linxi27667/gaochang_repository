(function () {
    'use strict';

    let simPhase = 'idle';
    let simTimer = 0;
    let uptimeSeconds = 0;

    // Smooth animation state
    const animState = {
        motor1: { display: 120.0, target: 120.0 },
        motor2: { display: 118.5, target: 118.5 },
        rafId: null,
    };

    function simulateData() {
        simTimer++;

        if (simPhase === 'idle' && simTimer > 30) {
            simPhase = 'rising';
            simTimer = 0;
            LiveData.systemState = SystemState.RISING;
        } else if (simPhase === 'rising' && simTimer > 80) {
            simPhase = 'idle';
            simTimer = 0;
            LiveData.systemState = SystemState.IDLE;
        }

        if (simPhase === 'rising') {
            LiveData.motor1.heightMm = Math.min(LiveData.motor1.heightMm + 0.8, LiveData.motor1.maxHeightMm);
            LiveData.motor2.heightMm = Math.min(LiveData.motor2.heightMm + 0.7 + Math.random() * 0.2, LiveData.motor2.maxHeightMm);
        } else {
            LiveData.motor1.heightMm += (Math.random() - 0.5) * 0.2;
            LiveData.motor2.heightMm += (Math.random() - 0.5) * 0.2;
        }

        LiveData.motor1.heightMm = Math.max(0, LiveData.motor1.heightMm);
        LiveData.motor2.heightMm = Math.max(0, LiveData.motor2.heightMm);
    }

    // requestAnimationFrame loop for smooth value animation
    function animateValues() {
        const speed = 0.12;
        let stillAnimating = false;

        for (const motor of ['motor1', 'motor2']) {
            const s = animState[motor];
            const diff = s.target - s.display;
            if (Math.abs(diff) > 0.05) {
                s.display += diff * speed;
                stillAnimating = true;
            } else {
                s.display = s.target;
            }
        }

        const m1El = document.getElementById('motor1-height');
        const m2El = document.getElementById('motor2-height');
        if (m1El) m1El.textContent = animState.motor1.display.toFixed(1);
        if (m2El) m2El.textContent = animState.motor2.display.toFixed(1);

        const m1Bar = document.getElementById('motor1-bar');
        const m2Bar = document.getElementById('motor2-bar');
        if (m1Bar) {
            m1Bar.style.width = (animState.motor1.display / LiveData.motor1.maxHeightMm * 100) + '%';
        }
        if (m2Bar) {
            m2Bar.style.width = (animState.motor2.display / LiveData.motor2.maxHeightMm * 100) + '%';
        }

        if (stillAnimating) {
            animState.rafId = requestAnimationFrame(animateValues);
        } else {
            animState.rafId = null;
        }
    }

    function startAnimationIfNeeded() {
        if (!animState.rafId) {
            animState.rafId = requestAnimationFrame(animateValues);
        }
    }

    function updateUI() {
        const { motor1, motor2, systemState, onlineCount, hasAlarm } = LiveData;
        if (typeof I18n === 'undefined') return;

        // Update animation targets instead of direct DOM
        animState.motor1.target = motor1.heightMm;
        animState.motor2.target = motor2.heightMm;
        startAnimationIfNeeded();

        // Motor state badges
        const s1El = document.getElementById('motor1-state');
        const s2El = document.getElementById('motor2-state');
        if (s1El) s1El.textContent = I18n.t(StateLabels[motor1.state] || 'status_idle');
        if (s2El) s2El.textContent = I18n.t(StateLabels[motor2.state] || 'status_idle');

        // Sync error
        const syncDiff = Math.abs(motor1.heightMm - motor2.heightMm);
        document.getElementById('sync-value').textContent = syncDiff.toFixed(1);

        // Sync dot color
        const syncDot = document.getElementById('sync-dot');
        if (syncDot) {
            syncDot.className = 'sync-dot';
            if (syncDiff > 10) syncDot.classList.add('danger');
            else if (syncDiff > 5) syncDot.classList.add('warning');
            else syncDot.classList.add('success');
        }

        // Current height (in meters)
        const currentHeightM = motor1.heightMm / 1000;
        document.getElementById('current-height-val').textContent = currentHeightM.toFixed(2);

        // System status
        document.getElementById('system-status-value').textContent = I18n.t(StateLabels[systemState] || 'status_idle');
        document.getElementById('headerSystemLabel').textContent = I18n.t(StateLabels[systemState] || 'status_idle');

        // Header status dot
        const headerDot = document.querySelector('#headerSystemStatus .status-dot');
        if (headerDot) {
            headerDot.className = 'status-dot';
            if (systemState === SystemState.ALARM) headerDot.classList.add('danger');
            else if (systemState === SystemState.IDLE) headerDot.classList.add('warning');
            else headerDot.classList.add('success');
        }

        // Online status
        document.getElementById('online-status-value').textContent = onlineCount + '/2';
        document.getElementById('headerOnlineLabel').textContent = onlineCount + '/2';

        // Alarm status
        document.getElementById('alarm-status-value').textContent = I18n.t(hasAlarm ? 'has_alarm' : 'no_alarm');
        const alarmCard = document.getElementById('alarmCard');
        if (alarmCard) {
            alarmCard.classList.toggle('has-alarm', hasAlarm);
        }

        // Header sync label
        document.getElementById('headerSyncLabel').textContent = I18n.t(syncDiff <= 2 ? 'sync_ok' : syncDiff <= 5 ? 'sync_warn' : 'sync_error_label');
    }

    function updateUptime() {
        uptimeSeconds++;
        const h = String(Math.floor(uptimeSeconds / 3600)).padStart(2, '0');
        const m = String(Math.floor((uptimeSeconds % 3600) / 60)).padStart(2, '0');
        const s = String(uptimeSeconds % 60).padStart(2, '0');
        const el = document.getElementById('uptime');
        if (el) el.textContent = '运行 ' + h + ':' + m + ':' + s;
    }

    let tickCount = 0;
    function tick() {
        simulateData();
        updateUI();
        tickCount++;
        if (tickCount % 10 === 0) {
            updateUptime();
        }
    }

    window.startSimulation = function () {
        setInterval(tick, 100);
        updateUptime();
    };
})();
